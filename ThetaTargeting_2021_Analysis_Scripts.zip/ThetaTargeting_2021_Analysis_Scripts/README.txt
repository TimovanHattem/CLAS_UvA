FILE DESCRIPTIONS (by Timo van Hattem, 5-8-2021)

- 'Real-time' stores all MATLAB scripts that are used for preprocessing and analysing data from the online theta targeting experiment (e.g., ERP analysis script, TFA analysis script, preprocessing script).
- 'Simulations' stores all MATLAB scripts that are used for preprocessing and analysing data from the offline simulations of the theta targeting experiment.

(For further information, please contact João Patriota or Timo van Hattem)
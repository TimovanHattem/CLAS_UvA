%% ACCURACY ANALYSIS OF SIMULATIONS
% FILE SIGNAL FROM EVENTIDE NEEDED

% Clear workspace
clear all
close all
clc

% Set path
if isempty(strfind(path, ['/home/Public/Projects/sleep-and-cognition/generic/matlab-scripts/toolboxes/eeglab_v2020', pathsep]))
    addpath('/home/Public/Projects/sleep-and-cognition/generic/matlab-scripts/toolboxes/eeglab_v2020');
end
addpath(genpath('/home/Public/Projects/sleep-and-cognition/experiments/0016.Measuring-theta-during-REM-sleep/simulations'));
addpath('/home/Public/Projects/sleep-and-cognition/generic/matlab-scripts/toolboxes/CircStat2012a');
addpath(genpath('/home/Public/Projects/sleep-and-cognition/experiments/0016.Measuring-theta-during-REM-sleep/matlab-scripts')); % to get e.g. 'bandpass.m'
fprintf('Paths added!\n')

% Setting output file path
DATAOUT = ['/home/Public/Projects/sleep-and-cognition/experiments/0016.Measuring-theta-during-REM-sleep/simulations/acc'];

%%
%Shows all files with a .csv extension
%clear 
[FileName,PathName] = uigetfile('.csv');
%filee = horzcat(PathName, FileName);

%C = xlsread(filee); %this reads the file written on eventIDE
%column 1 = time, column 2 = voltage, column3 = marker 'stimulus', comlumn
%4 = exact marker time

C = csv2table(FileName);

Signal = table2array(C(:,2));
TimeStamps = table2array(C(:,1));
MarkerTime = table2array(C(:,4));
MarkerIndex = find(isnan(MarkerTime)== 0); 
MarkerExactTime = MarkerTime(MarkerIndex);
% Plot to see where did the markers were placed
% plot(TimeStamps, Signal)
% hold on
% plot(TimeStamps(MarkerIndex), Signal(MarkerIndex), '.','MarkerSize', 17)
%
fs = 512;
band = [4 8]; % 4 8 = theta;
% FilteredSignal = myfilter_cheby(band, Signal, fs); %Filtering on the desired band
% FilteredSignal = myfilter(band, Signal, fs); %Filtering on the desired band
% FilteredSignal = bandpass_filter(band, Signal, fs); %Filtering on the desired band
% FilteredSignal= bandpass_filter(Signal,1,band(1),band(2),fs);  
FilteredSignal = bandpass(Signal,1,band(1),band(2),fs);  
PhasesSignal = (hilbert(FilteredSignal));
PhasesMarkers = PhasesSignal(MarkerIndex);

Shift = angle(PhasesMarkers)+(pi/2);
TriggerPhases=Shift;

%
cmean=circ_mean(TriggerPhases);
if cmean <0
    cmean = (2*pi + cmean);
end 

cmedian = circ_median(TriggerPhases);
if cmedian<0
    cmedian= (2*pi + cmedian);
end

[P_value, Z_value] = circ_rtest(TriggerPhases);

stim_freq = (length(TriggerPhases)/(size(C,1)/512));

%% Plot Figure 
s=sprintf('Theta Targeting Simulations: \t%s', FileName);
s0=sprintf('Total number of markers = \t%.0f',length(TriggerPhases));
s1=sprintf(['Mean phase = \t%.2f ' char(176) 'C'],circ_rad2ang(cmean));
s2=sprintf(['Median phase = \t%.2f ' char(176) 'C'],circ_rad2ang(cmedian));
s3=sprintf('SD = \t%.2f',circ_rad2ang(circ_std(TriggerPhases)));
s4=sprintf('SE = \t%.2f',circ_rad2ang(circ_std(TriggerPhases)/(sqrt(length(TriggerPhases)))));
%s5=sprintf('Skewness (0=symm) = \t%.2f',circ_skewness(phase_vec'));
%s6=sprintf('Kurtosis (0=norm.d.) = \t%.2f',circ_kurtosis(phase_vec'));
s7 = sprintf('Z-value = \t%.5f,\t P-value = \t%.5f', Z_value, P_value);
s8 = sprintf('Stimulation frequency (total REM) = \t%.3f Hz', stim_freq); 

figure
circ_plot(TriggerPhases,'hist',[], 20,false,true,'linewidth',3,'color','r');
title({s,s0,s1,s2,s3,s4,s7,s8});
set(gcf, 'MenuBar', 'none') 
set(gcf, 'Toolbar', 'none') 
set(gcf, 'Position', get(0, 'Screensize'));

%% Save
figname = [DATAOUT, filesep ,FileName, '_accuracy.jpg'];  
saveas (gcf,figname);

% polarhistogram((Shift),20)
%%
% plot(TimeStamps, FilteredSignal)
% hold on
% plot(TimeStamps(MarkerIndex), FilteredSignal(MarkerIndex), '.','MarkerSize', 17)
% 







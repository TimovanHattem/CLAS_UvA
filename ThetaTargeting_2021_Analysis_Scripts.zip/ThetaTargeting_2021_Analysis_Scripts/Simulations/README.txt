FILE DESCRIPTIONS (by Timo van Hattem, 5-8-2021)

- 'Accuracy_analysis_simulations.m' is a MATLAB script to get the roseplots showing accuracy and precision from the offline simulations of the theta targeting experiment. This script uses the SignalFile.csv from EventIDE to detect the location of the markers and extract their instantaneous phase. Hence, the phase distributions of the markers are shown in roseplots as output. 
- 'csv2table.m' is a MATLAB function used in Accuracy_analysis_simulations.m to load a CSV file from EventIDE into MATLAB for further analysis. This customized function imports numeric data from a text file as a table of any size. Other functions in MATLAB are unable to do this due to the large size of the SignalFile.csv from EventIDE.
- 'getREMsignal.m' is a MATLAB script that extracts all the data points from the SignalFile.csv (from EventIDE) corresponding to periods of REM sleep. A sleep scoring file from Wonambi is required for this process. 

(For further information, please contact João Patriota or Timo van Hattem)
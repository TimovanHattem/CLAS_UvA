e %% Settings
% Clear workspace
clear all
close all
clc

% Set path
if isempty(strfind(path, ['/home/Public/Projects/sleep-and-cognition/generic/matlab-scripts/toolboxes/eeglab_v2020', pathsep]))
    addpath('/home/Public/Projects/sleep-and-cognition/generic/matlab-scripts/toolboxes/eeglab_v2020');
end
addpath(genpath('/home/Public/Projects/sleep-and-cognition/experiments/0016.Measuring-theta-during-REM-sleep/Raw data/EEG'));
addpath('/home/Public/Projects/sleep-and-cognition/generic/matlab-scripts/toolboxes/CircStat2012a');
addpath('/home/Public/Projects/sleep-and-cognition/experiments/0016.Measuring-theta-during-REM-sleep/matlab-scripts/2. ZMax Analysis/Algorithm Accuracy'); % to get e.g. 'bandpass.m'
addpath(genpath('/home/Public/Projects/sleep-and-cognition/experiments/0016.Measuring-theta-during-REM-sleep/simulations'));
fprintf('Paths added!\n')

% Setting output file path
DATAOUT = ['/home/Public/Projects/sleep-and-cognition/experiments/0009.simulation-theta/raw-data/rem_csv'];

%% Load  file
[file, name] = uigetfile('*.csv');
signal_data = readtable(file);
%signal_data = table2struct(signal_data);

%% Load sleep stage file
[sleepscorefile, sleepscorepath] = uigetfile('*.csv');
sleep_data = readtable(sleepscorefile);
sleep_data = table2struct(sleep_data);

%% Select REM epochs
REM_epochs = []; 
for i = 1:size(sleep_data, 1)
    if strcmpi(sleep_data(i).stage, 'REM')
        REM_epochs = [REM_epochs i]; % Vector with indices of REM epochs
    end
end

%%
csvREM = [];
for i = 1:length(REM_epochs)
    startx = sleep_data(REM_epochs(i)).start*512+1;
    endx = sleep_data(REM_epochs(i)).xEnd*512+1;
    REM_signal = table2array(signal_data(startx:endx,1));
    csvREM = vertcat(csvREM, REM_signal);
end

%%
%csvwrite([DATAOUT, '/Signaldata_p04_REMonly.csv'], csvREM)
dlmwrite([DATAOUT, '/Signaldata_p10_REMonly.csv'], csvREM, 'delimiter', ',', 'precision', 14);

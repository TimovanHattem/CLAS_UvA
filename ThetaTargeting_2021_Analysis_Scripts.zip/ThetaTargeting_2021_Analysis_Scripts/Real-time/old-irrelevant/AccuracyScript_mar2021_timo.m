% ANALYSIS ACCURACY THETA TARGETING
%
% Timo van Hattem & Joao Patriota
% Experiment Theta_Targeting
% Updated: 12-3-2021

%% Settings

% Clear workspace
clear all
close all
clc

% Set path
if isempty(strfind(path, ['/home/Public/Projects/sleep-and-cognition/generic/matlab-scripts/toolboxes/eeglab_v2020', pathsep]))
    addpath('/home/Public/Projects/sleep-and-cognition/generic/matlab-scripts/toolboxes/eeglab_v2020');
end
addpath(genpath('/home/Public/Projects/sleep-and-cognition/experiments/0016.Measuring-theta-during-REM-sleep/Raw data'));
addpath('/home/Public/Projects/sleep-and-cognition/generic/matlab-scripts/toolboxes/CircStat2012a');
addpath('/home/Public/Projects/sleep-and-cognition/experiments/0016.Measuring-theta-during-REM-sleep/matlab-scripts/2. ZMax Analysis/Algorithm Accuracy'); % to get e.g. 'bandpass.m', 'butter.m', 'filtfilt.m'
fprintf('Paths added!\n')

%% Load EEG dataset in eeglab
eeglab;
[eegfilename eegpath]= uigetfile('*.set');
fprintf('Loading the .set file containing EEG recording for this participant...\n')
EEG = pop_loadset('filename',eegfilename,'filepath',eegpath);
fprintf('EEG file loaded!\n')

%% Setting output file path
pp = EEG.part_num;
%mkdir(['/home/Public/Projects/sleep-and-cognition/experiments/0016.Measuring-theta-during-REM-sleep/results/ThetaTargeting_2021/Algorithm performance/Fz'], pp);
DATAOUT = ['/home/Public/Projects/sleep-and-cognition/experiments/0016.Measuring-theta-during-REM-sleep/results/ThetaTargeting_2021/Algorithm performance/Fz/',pp];

%% Apply filter on theta range [4-8 Hz]

% filt = 'FILT1';
% low_theta = [5];
% high_theta = [7];
% EEG_thetafilt = pop_eegfiltnew(EEG,low_theta,high_theta,[],0);

% % filt = 'FILT2';
% % [B,A] = butter(1,[(4/(512/2)), (8/(512/2))], 'bandpass');
% % EEG_thetafilt = filtfilt(B,A,EEG.data(6,:));

filt = 'FILT2';
ord = 1; %Filter order
Fs = EEG.srate; % 512; %Sampling rate in Hz 512 is the refa amplifier
theta_rang = [4 8];
EEG_thetafilt = bandpass(EEG.data(6,:),ord,theta_rang(1), theta_rang(2),Fs);

% filt = 'FILT3';
% ord = 2; %Filter order
% Fs = EEG.srate; % 512; %Sampling rate in Hz 512 is the refa amplifier
% theta_rang = [4 8];
% EEG_thetafilt = bandpass(EEG.data,ord,theta_rang(1), theta_rang(2),Fs);

%% Calculate Hilbert transform
hil_eeg = hilbert(EEG_thetafilt);

%% STIMULATION condition %%

%% Find markers STIMULATION condition
stimtrials = [];
for i = 1:size(EEG.event,2)
    if strcmpi(EEG.event(i).type,'102')
        stimtrials = [stimtrials, EEG.event(i).latency];
    end
end

%% Find prediction phases STIMULATION condition
hil_stims = hil_eeg(stimtrials);
phase_stim = angle(hil_stims)+(pi/2);
%save([DATAOUT, '/', EEG.part_num, '_phaseSTIM_', filt, '.mat'], 'phase_stim');

%% Statistics & Analysis STIMULATION condition
cmean = circ_mean(phase_stim', [], 1);
if cmean <0
    cmean = (2*pi + cmean);
end

cmedian = circ_median(phase_stim');
if cmedian<0
    cmedian= (2*pi + cmedian);
end

[P_value, Z_value] = circ_rtest(phase_stim');

totalremtime = length(EEG_thetafilt)/512;
predfreqstim = length(stimtrials)/totalremtime;

%% Plot roseplot STIMULATION condition
s=sprintf('%s: Stimulation condition',EEG.part_num);
s0=sprintf('Total number of markers = \t%.0f',length(phase_stim));
s1=sprintf(['Mean phase = \t%.2f ' char(176) 'C'],circ_rad2ang(cmean));
s2=sprintf(['Median phase = \t%.2f ' char(176) 'C'],circ_rad2ang(cmedian));
s3=sprintf('SD = \t%.2f',circ_rad2ang(circ_std(phase_stim')));
s4=sprintf('SE = \t%.2f',circ_rad2ang(circ_std(phase_stim')/(sqrt(length(phase_stim')))));
%s5=sprintf('Skewness (0=symm) = \t%.2f',circ_skewness(phase_vec'));
%s6=sprintf('Kurtosis (0=norm.d.) = \t%.2f',circ_kurtosis(phase_vec'));
%s7 = sprintf('Z-value = \t%.5f,\t P-value = \t%.5f', Z_value, P_value);
s8 = sprintf('Prediction frequency (total clean REM) = \t%.3f Hz', predfreqstim);

figure
circ_plot(phase_stim','hist',[], 20,false,true,'linewidth',2,'color','r');
title({s,s0,s8,s1,s2,s3,s4});
set(gcf, 'MenuBar', 'none')
set(gcf, 'Toolbar', 'none')
set(gcf, 'Position', get(0, 'Screensize'));

%% Save roseplot STIMULATION condition
%figname = [DATAOUT, '/', EEG.part_num, '_accuracy_roseplot_STIM_' EEG.chanlocs(6).labels, '_', filt, '.jpg'];
%saveas (gcf,figname);

%% SHAM CONDITION  %%

%% Find markers SHAM condition
shamtrials = [];
for i = 1:size(EEG.event,2)
    if strcmpi(EEG.event(i).type,'103')
        shamtrials = [shamtrials, EEG.event(i).latency];
    end
end

%% Find prediction phases SHAM condition
hil_sham = hil_eeg(shamtrials);
phase_sham = angle(hil_sham)+(pi/2);
%save([DATAOUT, '/', EEG.part_num, '_phaseSHAM_', filt, '.mat'], 'phase_sham');

%% Statistics & Analysis SHAM condition
cmean = circ_mean(phase_sham', [], 1);
if cmean <0
    cmean = (2*pi + cmean);
end

cmedian = circ_median(phase_sham');
if cmedian<0
    cmedian= (2*pi + cmedian);
end

[P_value, Z_value] = circ_rtest(phase_sham');

totalremtime = length(EEG_thetafilt)/512;
predfreqsham = length(shamtrials)/totalremtime;

%% Plot figure SHAM condition
s=sprintf('%s: Sham condition',EEG.part_num);
s0=sprintf('Total number of markers = \t%.0f',length(phase_sham));
s1=sprintf(['Mean phase = \t%.2f ' char(176) 'C'],circ_rad2ang(cmean));
s2=sprintf(['Median phase = \t%.2f ' char(176) 'C'],circ_rad2ang(cmedian));
s3=sprintf('SD = \t%.2f',circ_rad2ang(circ_std(phase_sham')));
s4=sprintf('SE = \t%.2f',circ_rad2ang(circ_std(phase_sham')/(sqrt(length(phase_sham')))));
%s5=sprintf('Skewness (0=symm) = \t%.2f',circ_skewness(phase_vec'));
%s6=sprintf('Kurtosis (0=norm.d.) = \t%.2f',circ_kurtosis(phase_vec'));
%s7 = sprintf('Z-value = \t%.5f,\t P-value = \t%.5f', Z_value, P_value);
s8 = sprintf('Prediction frequency (total clean REM) = \t%.3f Hz', predfreqsham);

figure
circ_plot(phase_sham','hist',[], 20,false,true,'linewidth',2,'color','r');
title({s,s0,s8,s1,s2,s3,s4});
set(gcf, 'MenuBar', 'none')
set(gcf, 'Toolbar', 'none')
set(gcf, 'Position', get(0, 'Screensize'));

%% Save roseplot SHAM condition
%figname = [DATAOUT, '/', EEG.part_num, '_accuracy_roseplot_SHAM_' EEG.chanlocs(6).labels, '_', filt, '.jpg'];
%saveas (gcf,figname);

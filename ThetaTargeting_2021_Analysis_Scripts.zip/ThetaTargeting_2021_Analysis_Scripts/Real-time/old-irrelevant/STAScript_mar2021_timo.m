%% Settings
close all
clear all
clc

% Set path
if isempty(strfind(path, ['/home/Public/Projects/sleep-and-cognition/generic/matlab-scripts/toolboxes/eeglab_v2020', pathsep]))
    addpath('/home/Public/Projects/sleep-and-cognition/generic/matlab-scripts/toolboxes/eeglab_v2020');
end
addpath(genpath('/home/Public/Projects/sleep-and-cognition/experiments/0016.Measuring-theta-during-REM-sleep/Raw data/EEG'));
addpath('/home/Public/Projects/sleep-and-cognition/generic/matlab-scripts/toolboxes/CircStat2012a');
addpath('/home/Public/Projects/sleep-and-cognition/experiments/0016.Measuring-theta-during-REM-sleep/matlab-scripts/2. ZMax Analysis/Algorithm Accuracy'); % to get e.g. 'bandpass.m'
addpath(genpath('/home/Public/Projects/sleep-and-cognition/experiments/0016.Measuring-theta-during-REM-sleep/results'));
fprintf('Paths added!\n')

%%

for i = 32
    
    % Clear workspace
    close all
    clc
    
    % Load EEG dataset in eeglab
    eeglab;
    eegfilename = ['P', num2str(i), '_epoched_STIM.set'];
    eegpath = ['/home/Public/Projects/sleep-and-cognition/experiments/0016.Measuring-theta-during-REM-sleep/results/ThetaTargeting_2021/STA/P', num2str(i)];
    fprintf('Loading the .set file containing EEG recording for this participant...\n')
    EEG_stim = pop_loadset('filename',eegfilename,'filepath',eegpath);
    eegfilename = ['P', num2str(i), '_epoched_SHAM.set'];
    eegpath = ['/home/Public/Projects/sleep-and-cognition/experiments/0016.Measuring-theta-during-REM-sleep/results/ThetaTargeting_2021/STA/P', num2str(i)];
    EEG_sham = pop_loadset('filename',eegfilename,'filepath', eegpath);
    fprintf('EEG file loaded!\n')
end


%%
ave_stim = mean(EEG_stim.data,3);
ave_sham = mean(EEG_sham.data,3);

%% Plot ERP image
figure;
x = [-256:1:511];
plot(x,ave_stim, 'b')
hold on
plot(x,ave_sham, 'r')
xlabel('Time')
xlim([-256 511])
ylabel('Average ERP (microV)')
line([0 0], [-30 30], 'color', 'black')
legend('sound', 'no sound')


% pop_erpimage(EEG_sound, 1);
% pop_erpimage(EEG_nosound,1)

% figure;
% [spectra102, freqs102] = spectopo(EEG_sound.data, 0, EEG_sound.srate, 'limits', [0,100]);
% figure;
% [spectra103, freqs103] = spectopo(EEG_nosound.data, 0, EEG_nosound.srate, 'limits', [0,100]);
% 
% spect = spectra102./spectra103;

%% Save epoched events
% pop_saveset(EEG_sound, 'filename', [EEG.part_num, '_epoched_102.set'], 'filepath', DATAOUT);
% pop_saveset(EEG_nosound, 'filename', [EEG.part_num, '_epoched_103.set'], 'filepath', DATAOUT);

%% Merging participants - GRAND AVERAGE

EEG12 = pop_loadset();
EEG13 = pop_loadset();
EEG14 = pop_loadset();
EEG15 = pop_loadset();
EEG16 = pop_loadset();
EEG17 = pop_loadset();
EEG18 = pop_loadset();
EEG19 = pop_loadset();
EEG20 = pop_loadset();
EEG21 = pop_loadset();
EEG22 = pop_loadset();
EEG23 = pop_loadset();
EEG24 = pop_loadset();
EEG25 = pop_loadset();
EEG26 = pop_loadset();
EEG27 = pop_loadset();
EEG28 = pop_loadset();
EEG29 = pop_loadset();
EEG30 = pop_loadset();
EEG31 = pop_loadset();
EEG32 = pop_loadset();
EEG32 = pop_loadset();
EEG33 = pop_loadset();
EEG34 = pop_loadset();
EEG35 = pop_loadset();

out103 = pop_mergeset([EEG12,EEG13,EEG14,EEG15,EEG16,EEG17,EEG18,EEG19,EEG20,EEG21,EEG22,EEG23,EEG24,EEG25,EEG26,EEG27,EEG28,EEG29,EEG30,EEG31,EEG32,EEG33,EEG34,EEG35]);
%pop_saveset(OUTEEG, 'filename', 'EEG_102_average.set', 'filepath', DATAOUT);


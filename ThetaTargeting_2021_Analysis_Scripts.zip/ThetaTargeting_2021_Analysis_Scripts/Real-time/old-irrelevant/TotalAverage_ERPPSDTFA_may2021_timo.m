% ANALYSIS AVERAGES FOR ERP/TFA/PSD ANALYSIS THETA TARGETING
%
% Timo van Hattem & Joao Patriota
% Experiment Theta_Targeting
% Updated: 1-6-2021

%% SETTINGS

clear all
close all
clc

% Set pathS
if isempty(strfind(path, ['/home/Public/Projects/sleep-and-cognition/generic/matlab-scripts/toolboxes/eeglab_v2020', pathsep]))
    addpath('/home/Public/Projects/sleep-and-cognition/generic/matlab-scripts/toolboxes/eeglab_v2020');
end
addpath(genpath('/home/Public/Projects/sleep-and-cognition/experiments/0016.Measuring-theta-during-REM-sleep/Raw data'));
addpath('/home/Public/Projects/sleep-and-cognition/experiments/0016.Measuring-theta-during-REM-sleep/matlab-scripts/2. ZMax Analysis/Algorithm Accuracy'); % to get e.g. 'bandpass.m'
addpath(genpath('/home/Public/Projects/sleep-and-cognition/experiments/0016.Measuring-theta-during-REM-sleep/results'));
fprintf('Paths added!\n')

%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%ERP%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

load('ERP_INFORMATION_ALLPARTICIPANTS.mat')

DATAOUT = ['/home/Public/Projects/sleep-and-cognition/experiments/0016.Measuring-theta-during-REM-sleep/results/ThetaTargeting_2021/STA/TOTAL AVERAGE'];

% Averaging trials
for i = 1:size(ERP_info_allpp,2)
    erpmat_stim(i,:) = ERP_info_allpp(i).AverageERPStim;
    erpmat_sham(i,:) = ERP_info_allpp(i).AverageERPSham;
end

totalaverage_erp_stim = mean(erpmat_stim,1);
totalaverage_erp_sham = mean(erpmat_sham,1);

% Plot ERP image
figure;
x = [-256:1:511];
plot(x,totalaverage_erp_stim, 'b')
hold on
plot(x,totalaverage_erp_sham, 'r')
xlim([-256 511])
xlabel('Time (ms)')
ylabel(['Amplitude (', char(181),'V)'])
line([0 0], [-30 30], 'color', 'black')
legend('Stimulation', 'Sham')

%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%PSD%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

load('PSD_INFORMATION_ALLPARTICIPANTS.mat')

for i = 1:size(PSD_info_allpp,2)
    psdmat_stim(i,:) = PSD_info_allpp(i).MeanPowerStim;
    psdmat_sham(i,:) = PSD_info_allpp(i).MeanPowerSham;
    psdmat_ratio(i,:) = PSD_info_allpp(i).MeanPowerRatio;
end

totalaverage_psd_stim = mean(psdmat_stim,1);
totalaverage_psd_sham = mean(psdmat_sham,1);
totalaverage_psd_ratio = mean(psdmat_ratio,1);
hoi1 = PSD_info_allpp(:).MeanBandpowerStim;
hoi2 = PSD_info_allpp(:).MeanBandpowerSham;
totalaverage_bandstim = mean(hoi1,1);
totalaverage_bandsham = mean(hoi2,1);

% Plot Power spectrum
figure
subplot 131
plot(Fwel_stim,10*log10(totalaverage_psd_stim))                % Plot for the baseline window
hold on
plot(Fwel_stim,10*log10(totalaverage_psd_sham))            % Plot for the presentation window
line([theta_range(1) theta_range(1)], [0 20], 'color', 'red'); %Create a tick mark at x = t1(i) with a height of 100
line([theta_range(2) theta_range(2)], [0 20], 'color', 'red'); %Create a tick mark at x = t1(i) with a height of 100
legend('stim','no stim')
xlim([2 30])
axis square
subplot 132
plot(Fwel_stim,totalaverage_psd_ratio)
line([1 40], [1 1], 'color', 'red','LineStyle','--'); %Create a tick mark at x = t1(i) with a height of 100
xlim([2 40])
axis square
subplot 133
bandpower_comb = [totalaverage_bandstim, totalaverage_bandsham];
bar(bandpower_comb)
axis square

%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%TFA%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

load('TFA_INFORMATION_ALLPARTICIPANTS.mat')

for i = 1:size(TFA_info_allpp,2)
    tfamat_stim(:,:,i) = TFA_info_allpp(i).TFAStimP;
    tfamat_sham(:,:,i) = TFA_info_allpp(i).TFAShamP;
end

P1 = mean(tfamat_stim,3);
P2 = mean(tfamat_sham,3);

T1 = TFA_info_allpp(1).TFAStimT;
F1 = TFA_info_allpp(1).TFAStimF;
T2 = TFA_info_allpp(1).TFAStimT;
F2 = TFA_info_allpp(1).TFAStimF;

figure(1)
plot3([0 0],[-10 40],[0 600],'w','LineWidth',3)
hold on
plot3([-0.3 0.8],[3 3],[0 200],'--w','LineWidth',1)
plot3([-0.3 0.8],[8 8],[0 200],'--w','LineWidth',1)
hold on
surf(T1,F1,10*log10(abs(P1)),'EdgeColor','none');
axis xy; axis tight; view(0,90);
xlabel('Time', 'FontSize', 18);
ylabel('Frequency (Hz)', 'FontSize', 18);
title('Spectrogram Stimulation')
colorbar
ylim([2 30])
caxis([-25 12])

figure(2)
surf(T2,F2,10*log10(abs(P2)),'EdgeColor','none');
hold on
plot3([0 0],[-10 40],[0 600],'w','LineWidth',3)
plot3([-0.3 0.8],[3 3],[0 200],'--w','LineWidth',1)
plot3([-0.3 0.8],[8 8],[0 200],'--w','LineWidth',1)
axis xy; axis tight; view(0,90);
xlabel('Time', 'FontSize', 18);
ylabel('Frequency (Hz)', 'FontSize', 18);
title('Spectogram Sham')
colorbar
ylim([2 30])
caxis([-25 12])

figure(3)
surf(T2,F2,10*log10(abs(P1-P2)),'EdgeColor','none');
hold on
plot3([0 0],[-10 40],[0 600],'w','LineWidth',3)
plot3([-0.3 0.8],[3 3],[0 200],'--w','LineWidth',1)
plot3([-0.3 0.8],[8 8],[0 200],'--w','LineWidth',1)
axis xy; axis tight; view(0,90);
xlabel('Time', 'FontSize', 18);
ylabel('Frequency (Hz)', 'FontSize', 18);
title('Contrast (Stim-Sham)')
colorbar
ylim([2 30])
caxis([-5 10])

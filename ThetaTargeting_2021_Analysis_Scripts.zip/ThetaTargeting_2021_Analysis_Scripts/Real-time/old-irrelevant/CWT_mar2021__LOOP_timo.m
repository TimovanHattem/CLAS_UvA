% ANALYSIS FOR TFA/PSD ANALYSIS THETA TARGETING
%
% Timo van Hattem & Joao Patriota
% Experiment Theta_Targeting
% Updated: 1-6-2021

%% SETTINGS

clear all
close all
clc

% Set pathS
if isempty(strfind(path, ['/home/Public/Projects/sleep-and-cognition/generic/matlab-scripts/toolboxes/eeglab_v2020', pathsep]))
    addpath('/home/Public/Projects/sleep-and-cognition/generic/matlab-scripts/toolboxes/eeglab_v2020');
end
addpath(genpath('/home/Public/Projects/sleep-and-cognition/experiments/0016.Measuring-theta-during-REM-sleep/Raw data'));
addpath('/home/Public/Projects/sleep-and-cognition/experiments/0016.Measuring-theta-during-REM-sleep/matlab-scripts/2. ZMax Analysis/Algorithm Accuracy'); % to get e.g. 'bandpass.m'
addpath(genpath('/home/Public/Projects/sleep-and-cognition/experiments/0016.Measuring-theta-during-REM-sleep/results'));
fprintf('Paths added!\n')

%% LOOP OVER ALL PARTICIPANTS
z = 1;

for i = 12
    
    % Clear workspace
    close all
    clc
    
    % Load EEG dataset in eeglab
    eeglab;
    eegfilename = ['P', num2str(i), '_epoched_clean_STIM.set'];
    eegpath = ['Y:\Projects\Project Sleep and cognition\experiments\0016.Measuring-theta-during-REM-sleep\results\ThetaTargeting_2021\STA\P', num2str(i)];
    EEG_stim = pop_loadset('filename',eegfilename,'filepath',eegpath);
    eegfilename = ['P', num2str(i), '_epoched_clean_SHAM.set'];
    eegpath = ['Y:\Projects\Project Sleep and cognition\experiments\0016.Measuring-theta-during-REM-sleep\results\ThetaTargeting_2021\STA\P', num2str(i)];
    EEG_sham = pop_loadset('filename',eegfilename,'filepath', eegpath);
    fprintf('EEG file loaded!\n')
    
    % Setting output file path
    pp = EEG_stim.part_num;
    if strcmpi(pp,'P66')
        pp = 'P16';
    end
    %DATAOUT = ['/home/Public/Projects/sleep-and-cognition/experiments/0016.Measuring-theta-during-REM-sleep/results/ThetaTargeting_2021/STA/',pp];
    
    % Reshape data
    for j = 1:size(EEG_stim.data,3)
        data_stim(j,:) = EEG_stim.data(:,:,j);
        EEG_data_stim = double(data_stim);
        %save(['/home/Public/Projects/sleep-and-cognition/experiments/0016.Measuring-theta-during-REM-sleep/results/ThetaTargeting_2021/STA/',pp, '/', pp,'_epochs_stim_nonset.mat'], 'EEG_data_stim');
    end
    for k = 1:size(EEG_sham.data,3)
        data_sham(k,:) = EEG_sham.data(:,:,k);
        EEG_data_sham = double(data_sham);
        %save(['/home/Public/Projects/sleep-and-cognition/experiments/0016.Measuring-theta-during-REM-sleep/results/ThetaTargeting_2021/STA/',pp, '/', pp,'_epochs_sham_nonset.mat'], 'EEG_data_sham');
    end
    
    ERP_average_stim_evoked = (mean(EEG_data_stim,1));
    ERP_average_sham_evoked = (mean(EEG_data_sham,1));
    
    [wt, f] = cwt(ERP_average_stim_evoked, 'amor', EEG_stim.srate);
%     figure
%     plot3([0 0],[-10 40],[0 600],'w','LineWidth',3)
%     hold on
%     plot3([-0.375 0.875],[3 3],[0 200],'--w','LineWidth',1)
%     plot3([-0.375 0.875],[8 8],[0 200],'--w','LineWidth',1)
%     hold on
%     surf(T1,F1,10*log10(abs(P1)),'EdgeColor','none');
%     axis xy; axis tight; view(0,90);
%     xlabel('Time', 'FontSize', 18);
%     ylabel('Frequency (Hz)', 'FontSize', 18);
%     title('Spectrogram Stimulation')
%     colorbar
%     ylim([2 30])
%     caxis([-25 12])
fga
sdf
d
d
end

%% Settings
close all
clear all
clc

% Set path
if isempty(strfind(path, ['/home/Public/Projects/sleep-and-cognition/generic/matlab-scripts/toolboxes/eeglab_v2020', pathsep]))
    addpath('/home/Public/Projects/sleep-and-cognition/generic/matlab-scripts/toolboxes/eeglab_v2020');
end
addpath(genpath('/home/Public/Projects/sleep-and-cognition/experiments/0016.Measuring-theta-during-REM-sleep/Raw data/EEG'));
addpath('/home/Public/Projects/sleep-and-cognition/generic/matlab-scripts/toolboxes/CircStat2012a');
addpath('/home/Public/Projects/sleep-and-cognition/experiments/0016.Measuring-theta-during-REM-sleep/matlab-scripts/2. ZMax Analysis/Algorithm Accuracy'); % to get e.g. 'bandpass.m'
addpath(genpath('/home/Public/Projects/sleep-and-cognition/experiments/0016.Measuring-theta-during-REM-sleep/results'));
fprintf('Paths added!\n')

DATAOUT = ['/home/Public/Projects/sleep-and-cognition/experiments/0016.Measuring-theta-during-REM-sleep/results/theta_targeting_2021/STA'];

%% Open data
eeglab;
[eegfilename eegpath]= uigetfile('*.set');
EEG = pop_loadset('filename',eegfilename,'filepath',eegpath);

%% Epoch around marker events
[EEG_sound, indx2] = pop_epoch(EEG, {'102'}, [-0.5,0.5], 'valuelim', [-250, 250]);
[EEG_nosound, indx3] = pop_epoch(EEG, {'103'}, [-0.5,0.5],'valuelim', [-250, 250]);

%% Baseline correction
EEG_sound = pop_rmbase(EEG_sound, [-500 0]);
EEG_nosound = pop_rmbase(EEG_nosound, [-500 0]);

%% Artefact rejection 
pop_eegplot(EEG_sound,1,1,1); 
% rejtrial_sound = [];
% indexes_sound = 1:size(EEG_sound.data,3);
% idx_keep_sound = ismember(indexes_sound, rejtrial_sound); 
% EEG_sound = pop_rejepoch(EEG_sound, idx_keep_sound);

pop_eegplot(EEG_nosound,1,1,1); 
% rejtrial_nosound = [];
% indexes_nosound = 1:size(EEG_nosound.data,3);
% idx_keep_nosound = ismember(indexes_nosound, rejtrial_nosound);
% EEG_nosound = pop_rejepoch(EEG_nosound, idx_keep_nosound);

%%
ave_102 = mean(EEG_sound.data,3);
ave_103 = mean(EEG_nosound.data,3);
mat_ave102(1,:) = ave_102; 
mat_ave103(1,:) = ave_103;

%% Plot ERP image
figure;
x = [-256:1:255];
plot(x,ave_102, 'b')
hold on
plot(x,ave_103, 'r')
xlabel('Time')
xlim([-256 255])
ylabel('Average ERP (microV)')
line([0 0], [-30 30], 'color', 'black')
legend('sound', 'no sound')

% pop_erpimage(EEG_sound, 1);
% pop_erpimage(EEG_nosound,1)

% figure;
% [spectra102, freqs102] = spectopo(EEG_sound.data, 0, EEG_sound.srate, 'limits', [0,100]);
% figure;
% [spectra103, freqs103] = spectopo(EEG_nosound.data, 0, EEG_nosound.srate, 'limits', [0,100]);
% 
% spect = spectra102./spectra103;

%% Save epoched events
% pop_saveset(EEG_sound, 'filename', [EEG.part_num, '_epoched_102.set'], 'filepath', DATAOUT);
% pop_saveset(EEG_nosound, 'filename', [EEG.part_num, '_epoched_103.set'], 'filepath', DATAOUT);

%% Merging participants - GRAND AVERAGE

% EEG4 = pop_loadset()
% EEG5 = pop_loadset()
% EEG6 = pop_loadset()
% EEG7 = pop_loadset()
% EEG8 = pop_loadset()
% EEG9 = pop_loadset()
% EEG10 = pop_loadset()
% EEG11 = pop_loadset()

%  %OUTEEG = pop_mergeset([EEG4,EEG5,EEG6,EEG7,EEG8,EEG9,EEG10,EEG11]);
% % pop_saveset(OUTEEG, 'filename', 'EEG_103_average.set', 'filepath', DATAOUT);


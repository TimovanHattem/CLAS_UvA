%% Fz analysis of p05
 
% % 
% % load ('C:\Users\joaoh\Surfdrive\PhD\MATLAB\data\Theta_targeting\P05_fz_onlyrem')
% % restoredefaultpath;matlabrc
 eeglab
count_table = 1;
%%
close all

clearvars -except count_table Table_results
%
EEG_newchannels_plusone = pop_loadset;

%%
count_table = count_table+1;
% Filtering data
EEG_data = double(EEG_newchannels_plusone.data);
eeg_events = EEG_newchannels_plusone.event;
% filtered_data = myfilter([0.1, 100], EEG_data, 512);
for i = 1:size(eeg_events,2)
    
 labels(i,1) = str2double(eeg_events(i).type);   
 labels(i,2) =(eeg_events(i).latency);   
   
end
%% Finding proper labels
waiting_markers = labels == 100;
waiting_latencies = labels(waiting_markers,2);

targeting_markers = labels == 101;
targeting_latencies = labels(targeting_markers,2);

sound_markers = labels == 102;
sound_latencies = labels(sound_markers,2);

nosound_markers = labels == 103;
nosound_latencies = labels(nosound_markers,2);

pause_markers = labels == 104;
pause_latencies = labels(pause_markers,2);

break_markers = labels == 105;
break_latencies = labels(break_markers,2);



% %% Plot to see the whole signal with markers
% 
% figure(1)
% for k = 1:length(waiting_latencies) %Loop through each spike time
%     hold on
% 	line([waiting_latencies(k) waiting_latencies(k)], [(EEG_data(round(waiting_latencies(k)))-1000) (EEG_data(round(waiting_latencies(k)))+1000)], 'color', 'green'); %Create a tick mark at x = t1(i) with a height of 100
% end
% 
% for k = 1:length(nosound_latencies) %Loop through each spike time
%     hold on
% 	line([nosound_latencies(k) nosound_latencies(k)], [(EEG_data(round(nosound_latencies(k)))-1000) (EEG_data(round(nosound_latencies(k)))+1000)], 'color', 'red'); %Create a tick mark at x = t1(i) with a height of 100
% end
% 
% figure(1)
% for k = 1:length(sound_latencies) %Loop through each spike time
%     hold on
% 	line([sound_latencies(k) sound_latencies(k)], [(EEG_data(round(sound_latencies(k)))-1000) (EEG_data(round(sound_latencies(k)))+1000)], 'color', 'blue'); %Create a tick mark at x = t1(i) with a height of 100
% end
% 
% for k = 1:length(pause_latencies) %Loop through each spike time
%     hold on
% 	line([pause_latencies(k) pause_latencies(k)], [(EEG_data(round(pause_latencies(k)))-1000) (EEG_data(round(pause_latencies(k)))+1000)], 'color', 'yellow'); %Create a tick mark at x = t1(i) with a height of 100
% end
% 
% for k = 1:length(break_latencies) %Loop through each spike time
%     hold on
% 	line([break_latencies(k) break_latencies(k)], [(EEG_data(round(break_latencies(k)))-1000) (EEG_data(round(break_latencies(k)))+1000)], 'color', 'black'); %Create a tick mark at x = t1(i) with a height of 100
% end
% hold on
% plot(EEG_data)
% % legend
% plot (nosound_latencies,40000,'b.','MarkerSize', 17);
%% Finding blocks length 
% soundblock1 = sound_markers(1) - 512; %first sound marker - 512 indexes, getting one second prior
idx_pause = find(labels(:,1)== 104); 
count = 0;
for i = 2:length(idx_pause)
        labels((idx_pause(i-1):idx_pause(i)),3) = i;     
end

%Writing to the first and to the last block
labels(labels(:,3) < 2,3) = 1;
last_label = find(labels(:,3) == max(labels(:,3)));
labels(last_label(end):length(labels),3) = max(labels(:,3)) +1;

%% Excluding 
labels2 = labels;
labels2(labels2(:,1) == 101,:) = []; %excluding 101 markers
labels2(labels2(:,1) == 100,:) = []; %excluding 100 markers
%looping through all numbered blocks

blocks_number = unique(labels2(:,3));
for i = 1:length(blocks_number)

    BlockLogic = labels2(:,3) == blocks_number(i);
    
    BlockInfo(i,2) = max(labels2(BlockLogic, 2))+512; %timestamp block end (adding 512 to check 1s after the last stimulus
    BlockInfo(i,1) = min(labels2(BlockLogic, 2)); %timestamp block start 
    BlockInfo(i,4) = min(labels2(BlockLogic, 1)); %type marker start
    BlockInfo(i,3) = max(labels2(BlockLogic, 1)); %type marker end
    BlockInfo(i,5) = i; %block #
    BlockInfo(i,6) = sum(BlockLogic); %Number of markers (excluding 101 and 100)
    BlockInfo(i,7) =(BlockInfo(i,2) - BlockInfo(i,1))/512; %block duration in seconds
end

%% Plotting the different blocks on the eeg signal
% 
% for k = 1:length(BlockInfo) %Loop through each spike time
%     hold on
% 	line([BlockInfo(k,1) BlockInfo(k,1)], [(EEG_data(round(BlockInfo(k,1)))-1000) (EEG_data(round(BlockInfo(k,1)))+1000)], 'color', 'black'); %Create a tick mark at x = t1(i) with a height of 100
%     line([BlockInfo(k,2) BlockInfo(k,2)], [(EEG_data(round(BlockInfo(k,2)))-1500) (EEG_data(round(BlockInfo(k,2)))+1500)], 'color', 'red'); %Create a tick mark at x = t1(i) with a height of 100
% end
% hold on
% plot(EEG_data)

%% Exploratory figure to checking spectrogram for each block
% figure
close all
k = 15; %loop this to get specific cutouts
filtered_EEGclean = myfilter([0.1, 100], EEG_data(round(BlockInfo(k,1):round(BlockInfo(k,2)))), 512);
MarkersToPlot = round(labels2((labels2(:,3)==k),2));
MarkersToPlot = (MarkersToPlot-(round(BlockInfo(k,1))))/512;

[s,F,T,P]=spectrogram(filtered_EEGclean,800,600,1000,512); % Computes the spectrogram
figure(6)
%
surf(T,F,10*log10(abs(P)),'EdgeColor','none');
axis xy; axis tight; view(0,90);
xlabel('Time');
ylabel('Frequency (Hz)');
colorbar
ylim([1 25])
caxis([0 20])
hold on 
for i = 1:length(MarkersToPlot)
    
    plot3([MarkersToPlot(i) MarkersToPlot(i)],[-10 40],[0 200],'r','LineWidth',3)
    
end
title(num2str(BlockInfo(k,4)));
figurename6 = [EEG_newchannels_plusone.filename(1:(end-4)) '_figure6.png'];
saveas(gcf,figurename6)

k = 16; %loop this to get specific cutouts
filtered_EEGclean = myfilter([0.1, 100], EEG_data(round(BlockInfo(k,1):round(BlockInfo(k,2)))), 512);
MarkersToPlot = round(labels2((labels2(:,3)==k),2));
MarkersToPlot = (MarkersToPlot-(round(BlockInfo(k,1))))/512;

[s,F,T,P]=spectrogram(filtered_EEGclean,800,600,1000,512); % Computes the spectrogram
figure(7)
%
surf(T,F,10*log10(abs(P)),'EdgeColor','none');
axis xy; axis tight; view(0,90);
xlabel('Time');
ylabel('Frequency (Hz)');
colorbar
ylim([1 25])
caxis([0 20])
hold on 
for i = 1:length(MarkersToPlot)
    
    plot3([MarkersToPlot(i) MarkersToPlot(i)],[-10 40],[0 200],'r','LineWidth',3)
    
end
title(num2str(BlockInfo(k,4)));
figurename7 = [EEG_newchannels_plusone.filename(1:(end-4)) '_figure7.png'];
saveas(gcf,figurename7)
%% PSD for blocks
minsounds = 10; %minimum number of sounds to consider a block 
SoundBlock = [];
NoSoundBlock = [];
filterrange = [1 40];
%concatenating data bits of each trial type
for k = 1:length(BlockInfo)
    if BlockInfo(k,4) == 102 && BlockInfo(k,6) >=minsounds
        if round(BlockInfo(k,2))> size(EEG_data,2)
            
        else
            SoundBlock = horzcat(SoundBlock, EEG_data(round(BlockInfo(k,1):round(BlockInfo(k,2))))); %concatenating every signal from the sound block
        end
    end
    
    if BlockInfo(k,4) == 103 && BlockInfo(k,6) >=minsounds
        NoSoundBlock = horzcat(NoSoundBlock, EEG_data(round(BlockInfo(k,1):round(BlockInfo(k,2))))); %concatenating every signal from the no sound block
    end
end

% Removing dummy values
SoundBlock(SoundBlock == -300) = [];
NoSoundBlock(NoSoundBlock == -300) = [];

%% Filtering and PSD
filtered_sound = myfilter_cheby(filterrange, SoundBlock, 512);
filtered_nosound = myfilter_cheby(filterrange, NoSoundBlock, 512);
%%
clear powerblocksound powerblocknosound f f1
window_block = 512;
[powerblocksound, f] = pwelch(filtered_sound,window_block,[],512,512);
[powerblocknosound, f1] = pwelch(filtered_nosound,window_block,[],512,512);
%
norm_powerblocksound = powerblocksound./max(powerblocksound);
norm_powerblocknosound = powerblocknosound./max(powerblocknosound);
power2_ratio_block = bandpower(powerblocksound,f,[4 8],'psd')/bandpower(powerblocknosound,f1,[4 8],'psd');
power2_ratio_block_norm = bandpower(norm_powerblocksound,f,[4 8],'psd')/bandpower(norm_powerblocknosound,f1,[4 8],'psd');

%%
figure (1) 
subplot 122
plot(f,10*log10(norm_powerblocksound),'b')
hold on
plot(f1,10*log10(norm_powerblocknosound),'r')
xlabel('Frequency (Hz)', 'FontSize', 18)
ylabel('Magnitude (dB)')
legend('Stim', 'No stim')
title(['bandpower ratio normalized ' num2str(power2_ratio_block_norm)])
axis square
xlim([1 30])

subplot 121
plot(f,10*log10(powerblocksound),'b')
hold on
plot(f1,10*log10(powerblocknosound),'r')
xlabel('Frequency (Hz)', 'FontSize', 18)
ylabel('Magnitude (dB)', 'FontSize', 18)
legend('Stim', 'No stim')
title(['bandpower ratio ' num2str(power2_ratio_block)])

axis square
xlim([1 30])
figurename1 = [EEG_newchannels_plusone.filename(1:(end-4)) '_figure1.png'];
saveas(gcf,figurename1)

%% Searching for STA's
EEG_data2 = EEG_data;
SoundSTA = [];
NoSoundSTA = [];
SoundSTA_nfilter = [];
NoSoundSTA_nfilter = [];
% EEG_data2(EEG_data2==-300) = nan;
filtered_EEGclean = myfilter_cheby([1, 40], EEG_data2, 512);

%%  
close all
clear SoundSTA NoSoundSTA SoundSTA_norm NoSoundSTA_norm SoundSTA_nfilter NoSoundSTA_nfilter
latency_sta_plus = 512; 
% latency_sta_back = round(latency_sta_plus/2);
latency_sta_back = 256;

% for i = 1:length(sound_latencies)
%     baseline_correction_nsound = mean(EEG_data2((sound_latencies(i)-latency_sta_back):(sound_latencies(i))));    
%     SoundSTA(i,:) = EEG_data2((sound_latencies(i)-latency_sta_back):(sound_latencies(i)+latency_sta_plus));
% end
% 
% for i = 1:length(nosound_latencies)
%     baseline_correction_nsound = mean(EEG_data2((nosound_latencies(i)-latency_sta_back):(nosound_latencies(i))));
%     NoSoundSTA(i,:) = EEG_data2((nosound_latencies(i)-latency_sta_back):(nosound_latencies(i)+latency_sta_plus))-baseline_correction_nsound;
% end
for i = 1:length(sound_latencies)
    interval_tofetchsound = (round(sound_latencies(i))- round(latency_sta_back):(round(sound_latencies(i))+ round(latency_sta_plus)));
%     baseline_correction_nsound = mean(filtered_EEGclean((sound_latencies(i)-latency_sta_back):(sound_latencies(i))));    
    SoundSTA(i,:) = filtered_EEGclean(interval_tofetchsound);
    SoundSTA_nfilter(i,:) = EEG_data2(interval_tofetchsound); %use non filtered values to find -300 trials
end

for i = 1:length(nosound_latencies)
    interval_tofetchnosound = (round(nosound_latencies(i))- round(latency_sta_back):(round(nosound_latencies(i))+ round(latency_sta_plus)));
%     baseline_correction_nsound = mean(filtered_EEGclean((nosound_latencies(i)-latency_sta_back):(nosound_latencies(i))));
    NoSoundSTA(i,:) = filtered_EEGclean(interval_tofetchnosound);
    NoSoundSTA_nfilter(i,:) = EEG_data2(interval_tofetchnosound); %use non filtered values to find -300 trials
end
%% quick check for overlapping latencies
for ii = 2:length(sound_latencies)
    diff_idx(ii-1) = sound_latencies(ii) - sound_latencies(ii-1);
%     diff_idx = diff_idx
end
clear ii
for ii = 2:length(nosound_latencies)
    diff_idxnsound(ii-1) = nosound_latencies(ii) - nosound_latencies(ii-1);
%     diff_idx = diff_idx
end
diff_idx = diff_idx./512;
diff_idxnsound = diff_idxnsound./512;
%% Removing rotten trials
rotten_idxsound = SoundSTA_nfilter(:,1) == -300;
rotten_idxnosound = NoSoundSTA_nfilter(:,1) == -300;
%%
SoundSTA(rotten_idxsound,:) = [];
NoSoundSTA(rotten_idxnosound,:) = [];
% NoSoundSTA(NoSoundSTA(:,end)==-300,:) = [];
% SoundSTA(SoundSTA(:,end)==-300,:) = [];
%%
% Normalizing each row
for i = 1:size(SoundSTA,1)
%     SoundSTA_norm(i,:) = SoundSTA(i,:)./max(SoundSTA(i,:));
    SoundSTA_norm(i,:) = zscore(SoundSTA(i,:));
end

for i = 1:size(NoSoundSTA,1)
%     NoSoundSTA_norm(i,:) = NoSoundSTA(i,:)./max(NoSoundSTA(i,:));
    NoSoundSTA_norm(i,:) = zscore(NoSoundSTA(i,:));
end
%
STA_soundmean = nanmean(SoundSTA);
STA_nosoundmean = nanmean(NoSoundSTA);

STA_soundmean_norm = nanmean(SoundSTA_norm);
STA_nosoundmean_norm = nanmean(NoSoundSTA_norm);
figure(2)
subplot 121
t_STA = (1:length(STA_soundmean_norm))-latency_sta_back;
plot(t_STA, STA_soundmean_norm);hold on; plot(t_STA,STA_nosoundmean_norm) %plot with it normalized
title('ERP (zscored)')

xlabel('Samples', 'FontSize', 18)
ylabel('zscore', 'FontSize', 18)
subplot 122
plot(t_STA, STA_soundmean);hold on; plot(t_STA,STA_nosoundmean) %plot with it normalized
title('ERP (not zscored)')

xlabel('Samples', 'FontSize', 18)
ylabel('mV', 'FontSize', 18)
line([0 0], [(min(STA_nosoundmean)) (max(STA_nosoundmean)) ], 'color', 'red'); %Create a tick mark at x = t1(i) with a height of 100
legend('stim','no stim')

figurename2 = [EEG_newchannels_plusone.filename(1:(end-4)) '_figure2.png'];
saveas(gcf,figurename2)
%todo AXIS SIZE
%% Pwelch for every line
clear pxx1 pxx2
theta_range = [4 8];
total_range = [1 40];
% theta_range = [3 7];
window = 500;
nooverlap = [];
fftsize = 2^10;
Fs = 512;
for i = 1:size(SoundSTA,1)
    [pxx1(i,:), f1] = pwelch(SoundSTA(i,:),window,nooverlap,fftsize,Fs);
end %########## USE THIS BLOCK FOR NOT NORMAL VALUES ############
for i = 1:size(NoSoundSTA,1)
    [pxx2(i,:), f2] = pwelch(NoSoundSTA(i,:),window,nooverlap,fftsize,Fs);
end
n_sounds = size(SoundSTA,1);
n_nosounds = size(NoSoundSTA,1);

% for i = 1:size(SoundSTA,1)
%     [pxx1(i,:), f1] = pwelch(SoundSTA_norm(i,:),window,nooverlap,fftsize,Fs); %using normalized values
% end
% for i = 1:size(NoSoundSTA,1)
%     [pxx2(i,:), f2] = pwelch(NoSoundSTA_norm(i,:),window,nooverlap,fftsize,Fs);
% end
%
close all 
meanpower_sound = mean(pxx1,1); %average power of power per 
bandpower_sound = bandpower(meanpower_sound,f1,theta_range,'psd'); %band on theta


meanpower_sound_norm = meanpower_sound/max(meanpower_sound); %normalizing meanpower
bandpower_sound_norm = bandpower(meanpower_sound_norm,f1,theta_range,'psd'); %normalized band on theta

bandpower_sound_total = bandpower(meanpower_sound,f1,total_range,'psd');  %bandpower on total
bandpower_sound_total_norm = bandpower(meanpower_sound_norm,f1,total_range,'psd'); %normalized bandpower on total

%same as before, but for nosound markers     

meanpower_nosound = mean(pxx2,1); %average power for no sound markers
bandpower_nosound = bandpower(meanpower_nosound,f2,theta_range,'psd'); %bandpower on no sound markers


meanpower_nosound_norm = meanpower_nosound/max(meanpower_nosound); %normalizing
bandpower_nosound_norm = bandpower(meanpower_nosound_norm,f2,theta_range,'psd'); %bandpower on normalized

bandpower_nosound_total = bandpower(meanpower_nosound,f2,total_range,'psd'); %bandpower on total
bandpower_nosound_total_norm = bandpower(meanpower_nosound_norm,f2,total_range,'psd'); %bandpower on normalized total
%

% meanpower_ratio_norm = (meanpower_sound_norm./meanpower_nosound_norm);
meanpower_ratio = (meanpower_sound./meanpower_nosound);
meanpower_ratio_norm = (meanpower_sound_norm./meanpower_nosound_norm);

%%
figure(3)
title_stim = ['Sound markers = ' num2str(n_sounds) ' No sound markers = ' num2str(n_nosounds) ' (absolute values)'];
title_zscore = ['Sound markers = ' num2str(n_sounds) ' No sound markers = ' num2str(n_nosounds) ' (zscore values)'];

suptitle(title_stim)
subplot 131
% plot(f1,10*log10((meanpower_sound./max(meanpower_sound))))
plot(f1,10*log10((meanpower_sound)))
xlabel('Frequency (Hz)', 'FontSize', 18)
ylabel('power (a.u)', 'FontSize', 18)

hold on
% plot(f2,10*log10((meanpower_nosound./max(meanpower_nosound))))
plot(f2,10*log10((meanpower_nosound)))
xlabel('Frequency (Hz)', 'FontSize', 18)
ylabel('ratio', 'FontSize', 18)

title(['bandpower ratio = ' num2str(round(bandpower_sound/bandpower_nosound,2))])
line([theta_range(1) theta_range(1)], [0 20], 'color', 'red'); %Create a tick mark at x = t1(i) with a height of 100
line([theta_range(2) theta_range(2)], [0 20], 'color', 'red'); %Create a tick mark at x = t1(i) with a height of 100
legend('stim','no stim')
xlim([2 30])
axis square

subplot 132

plot(f2,meanpower_ratio)
line([1 40], [1 1], 'color', 'red','LineStyle','--'); %Create a tick mark at x = t1(i) with a height of 100

% line([4 4], [min(bandpower_nosound_norm) max(bandpower_nosound_norm) ], 'color', 'red'); %Create a tick mark at x = t1(i) with a height of 100
% line([8 8], [min(bandpower_nosound_norm) max(bandpower_nosound_norm)], 'color', 'red'); %Create a tick mark at x = t1(i) with a height of 100
% ylim
xlim([2 40])
axis square
title('power ratio')

subplot 133
%
allocated_theta_sound(1,1) = (bandpower_sound/bandpower_sound_total)*100;

allocated_theta_sound(1,2) = (bandpower_nosound/bandpower_nosound_total)*100;
c = categorical({'Sound','No sound'});
bar(c, allocated_theta_sound)
% legend('sound','no sound')
axis square

figurename3 = [EEG_newchannels_plusone.filename(1:(end-4)) '_figure3.png'];
saveas(gcf,figurename3)

figure(4)
suptitle(title_zscore)

subplot 131
% plot(f1,10*log10((meanpower_sound./max(meanpower_sound))))
plot(f1,10*log10((meanpower_sound_norm)))
xlabel('Frequency (Hz)', 'FontSize', 18)
ylabel('power (a.u)', 'FontSize', 18)

hold on
% plot(f2,10*log10((meanpower_nosound./max(meanpower_nosound))))
plot(f2,10*log10((meanpower_nosound_norm)))
title(['bandpower ratio = ' num2str(round(bandpower_sound_norm/bandpower_nosound_norm,2))])
line([4 4], [(max(meanpower_nosound_norm)*10)-5 (min(meanpower_nosound_norm)*10)-10], 'color', 'red'); %Create a tick mark at x = t1(i) with a height of 100
line([8 8], [(max(meanpower_nosound_norm)*10)-5 (min(meanpower_nosound_norm)*10)-10], 'color', 'red'); %Create a tick mark at x = t1(i) with a height of 100
legend('stim','no stim')
xlim([2 30])
axis square

subplot 132

plot(f2,meanpower_ratio_norm)
line([1 40], [1 1], 'color', 'red','LineStyle','--'); %Create a tick mark at x = t1(i) with a height of 100

% line([4 4], [min(bandpower_nosound_norm) max(bandpower_nosound_norm) ], 'color', 'red'); %Create a tick mark at x = t1(i) with a height of 100
% line([8 8], [min(bandpower_nosound_norm) max(bandpower_nosound_norm)], 'color', 'red'); %Create a tick mark at x = t1(i) with a height of 100
% ylim
xlim([2 40])
xlabel('Frequency (Hz)', 'FontSize', 18)
ylabel('ratio', 'FontSize', 18)

axis square
title('power ratio')

subplot 133
%
allocated_theta_sound(1,1) = (bandpower_sound_norm/bandpower_sound_total_norm)*100;

allocated_theta_sound(1,2) = (bandpower_nosound_norm/bandpower_nosound_total_norm)*100;
c = categorical({'Sound','No sound'});
bar(c, allocated_theta_sound)
% legend('sound','no sound')
axis square
figurename4 = [EEG_newchannels_plusone.filename(1:(end-4)) '_figure4.png'];
saveas(gcf,figurename4)

%%
SoundSTA_norm_bigintervals = SoundSTA_norm(diff_idx>1,:);
NoSoundSTA_norm_bigintervals = NoSoundSTA_norm(diff_idxnsound>1,:);

n_sounds_big = size(SoundSTA_norm_bigintervals,1);
n_nosounds_big = size(NoSoundSTA_norm_bigintervals,1);

STA_soundmean_norm_big = nanmean(SoundSTA_norm_bigintervals);
STA_nosoundmean_norm_big = nanmean(NoSoundSTA_norm_bigintervals);

title_stim_big = ['Sound markers = ' num2str(n_sounds_big) ' No sound markers = ' num2str(n_nosounds_big) ' (zscore values)'];
% title_zscore_big = ['Sound markers = ' num2str(n_sounds) ' No sound markers = ' num2str(n_nosounds) ' (zscore values)'];

figure(5)
suptitle(title_stim_big)

window_spectrogram = 256;
nooverlap_spectrogram = 250;
[s1,F1,T1,P1]=spectrogram(STA_soundmean_norm_big,window_spectrogram,nooverlap_spectrogram,1024,512); % Computes the spectrogram
subplot 121
plot3([0 0],[-10 40],[0 600],'w','LineWidth',3)
hold on
plot3([-0.2 0.7],[3 3],[0 200],'--w','LineWidth',1)
plot3([-0.2 0.7],[8 8],[0 200],'--w','LineWidth',1)
hold on
T1 = T1-0.5;
surf(T1,F1,10*log10(abs(P1)),'EdgeColor','none');
axis xy; axis tight; view(0,90);
xlabel('Time', 'FontSize', 18);
ylabel('Frequency (Hz)', 'FontSize', 18);
title('spectrogram of average normalized signal w/ sound marker')

colorbar
ylim([1 30])
caxis([-50 -5])

[s,F,T,P]=spectrogram(STA_nosoundmean_norm_big,window_spectrogram,nooverlap_spectrogram,1024,512); % Computes the spectrogram
subplot 122
T = T-0.5;
surf(T,F,10*log10(abs(P)),'EdgeColor','none');
hold on
plot3([0 0],[-10 40],[0 600],'w','LineWidth',3)
plot3([-0.2 0.7],[3 3],[0 200],'--w','LineWidth',1)
plot3([-0.2 0.7],[8 8],[0 200],'--w','LineWidth',1)
axis xy; axis tight; view(0,90);
xlabel('Time', 'FontSize', 18);
ylabel('Frequency (Hz)', 'FontSize', 18);
title('spectrogram of average normalized signal without sound marker')

colorbar
ylim([1 30])
caxis([-50 -5])

% figurename5 = [EEG_newchannels_plusone.filename(1:(end-4)) '_figure5.png'];
% saveas(gcf,figurename5)
%% Statistical test
% If the assumptions for equal variance and normality are met, a paired
% t-test should be used to test if the LFP frequencies between stimulus 
% presentation and baseline differ significantly. 
% First we test the assumption of equal variance
[~,p1] = vartest2(meanpower_sound,meanpower_nosound); 
% H0: equal variance, HA: no equal variance
% Significance level: 0.05
% The test for equal variance gives a p-value of 0.8409, this means that the
% nul hypothesis cannot be rejected, thus the data has equal variance

[~,p2] = jbtest(meanpower_sound); 
[~,p3] = jbtest(meanpower_nosound);
% H0: normality, HA: non normality
% Significance level: 0.05
% The normality test for both datasets are significant [p<0.05 & p<0.05], meaning
% that both datasets are not normaly distributed.
% However, the t-test is very robust to non-normality, 
% therefore the parametric paired t-test could still be used

% First, we test if the power of the baseline window is significantly different
% from the power of the stimulus presentation window.
% We choose the parametrical paired t test 
% H0: means between two datasets are equal
% H0: means between two datasets are not equal
% Significance level: 0.05
[~,p4]=ttest(meanpower_sound,meanpower_nosound);
% The p-value is 1.683e-05, thus the nul hypothesis can be rejected. The
% alternative hypothesis is true: the power in de baseline window and the
% stimulus presentation window differ significantly.
%%

P_nsound_baseline = P(F>=4 & F<=8,T<=0);
P_sound_baseline = P1(F1>=4 & F1<=8,T1<=0);
%%
P_nsound = P(F>=4 & F<=8,T>0);
P_sound = P1(F1>=4 & F1<=8,T1>0);
%%
ranksum(mean(P_sound,1), mean(P_nsound,1))
ranksum(mean(P_sound_baseline,1), mean(P_nsound_baseline,1))
%%
mean(P_sound,1)
bandpower(mean(P_sound,2),F1(F1>=4 & F1<=8),[4 8],'psd')
bandpower(mean(P_nsound,2),F(F>=4 & F<=8),[4 8],'psd')
%% MAKING TABLE

Table_results(count_table,1) =  round(bandpower_sound/bandpower_nosound,2);
Table_results(count_table,2) =  round(bandpower_sound_norm/bandpower_nosound_norm,2);
Table_results(count_table,2) =  count_table;

disp('end')
%%
title('Distribution of theta increase')
plot(Table_results((1:end),2),Table_results((1:end),1),'.','MarkerSize',40)
hold on
line([1 8], [1 1], 'color', 'red','LineStyle','--'); %Create a tick mark at x = t1(i) with a height of 100
xlabel('Participant #')
ylabel('(sound/nosound)')
ylim([0.5 2])
xlim([0.8 8.2])
axis square
% PREPROCESSING EEG DATA
%
% This script uses already re-referenced data (see
% ConversionScript_feb2021.m). This script filters data, removes unused
% channels, selects REM epochs and does trial rejection on bad epochs based
% on visual inspection.
% The output is a set file with clean REM data, ready for further analyses.
%
% This script is partly an adaptation of a script bij VPathak & EJuan
%
% Timo van Hattem & Joao Patriota
% Experiment ThetaTargeting
% Updated: 4-2-2021

%% Settings
% Clear workspace
clear all
close all
clc

% Set path
if isempty(strfind(path, ['/home/Public/Projects/sleep-and-cognition/generic/matlab-scripts/toolboxes/eeglab_v2020', pathsep]))
    addpath('/home/Public/Projects/sleep-and-cognition/generic/matlab-scripts/toolboxes/eeglab_v2020');
end
addpath(genpath('/home/Public/Projects/sleep-and-cognition/experiments/0009.simulation-theta/raw-data/EEG'));
addpath('/home/Public/Projects/sleep-and-cognition/generic/matlab-scripts/toolboxes/CircStat2012a');
disp('added paths!')

% Setting output file path
DATAOUT = ['/home/Public/Projects/sleep-and-cognition/experiments/0009.simulation-theta/raw-data/EEG/preproc'];

%% Load EEG dataset in eeglab
eeglab;
[eegfilename eegpath]= uigetfile('*.set');
fprintf('Loading the .set file containing EEG recording for this participant...\n')
EEG = pop_loadset('filename',eegfilename,'filepath',eegpath);

%% Load sleep stage file
[sleepscorefile, sleepscorepath] = uigetfile('*.csv');
fprintf('Loading the .csv file containing sleepstaging for this participant...\n')
sleep_data = readtable(sleepscorefile);
sleep_data = table2struct(sleep_data);

%% Get participant info
part_num = 'P05'; % INPUT 
if isempty(part_num)
    error('Go to line 43 and give participant number');
end
EEG.part_num = part_num;

%% Input check datasets
%Get sampling rate data check if it is 512
Fs = EEG.srate;
if Fs ~= 512
    fprintf('Please check dataset, samplingrate is not 512Hz')
    fprintf('Press any button to continue processing')
    pause
end

% Epoch length that will be used in seconds
Epochlength = 30;

% Determine the length of the data in seconds
LengthDataSeconds = length(EEG.data)/Fs;

% Determine amount of samples in 1 epoch
EpochSrate = Fs*Epochlength;

% Determine number of epochs based on length of data and amount of samples
% in epoch
xepochsEEG = floor(length(EEG.data)/EpochSrate);

%Determine amount of epochs csv file
xepochsscore= size(sleep_data,1);

% Check if number of epochs matches the data and print result of check.
if xepochsEEG ~= xepochsscore
    difference = xepochsEEG - xepochsscore;
    fprintf('Difference between EEG epochs and sleep score epochs is: %f\n', difference)
    error('Number of epochs in EEG data does not match number of epochs in the sleep score file')
end
fprintf('Equal amount of epochs in EEG and sleep score file :) \n')
 
%% Remove non EEG channels
EEG = pop_select(EEG, 'nochannel', [65:68]);

%% Filter data
% EEG_filtered = pop_eegfiltnew(EEG, 0.15, 100, [], 0); %bandpass filter 0.1-100
% EEG_filtered = pop_eegfiltnew(EEG_filtered, 48, 52, [], 1); %notch filter 48-52
%pop_saveset(EEG_filtered,'filename',[eegfilename,'_filtered.set'],'filepath',DATAOUT);
%pop_eegplot(EEG_filtered,1,1,1);

%% Rereferencing
EEG_filtered = pop_reref(EEG_filtered,[13 19],'keepref', 'on'); %to have the same chanloc struct.

%% Divide EEG data into 30 seconds epochs
EEG_epoched =  eeg_regepochs(EEG_filtered,'recurrence',[30],'limits',[0 30]); 

%% Select REM epochs
REM_epochs = []; 
for i = 1:size(sleep_data, 1)
    if strcmpi(sleep_data(i).stage, 'REM')
        REM_epochs = [REM_epochs i]; % Vector with indices of REM epochs
    end
end
EEG_REMepochs = pop_select(EEG_epoched, 'trial', REM_epochs);                         
pop_eegplot(EEG_REMepochs,1,1,1);

epvector = 1:size(sleep_data,1);
NREM_epochs = setdiff(epvector, REM_epochs); % Vector with indices of NREM epochs

%% Select and extract channel of interest to see REM epochs
coi = 6; % INPUT channel of interest, Fz = 6, fpz = 2
EEG_newchannels = pop_select(EEG_REMepochs, 'channel', coi);
pop_eegplot(EEG_newchannels,1,1,1);

%% Inspect trials 
pop_eegplot(EEG_newchannels,1,1,1); % Settings > Time range = 1 epoch, range = 200

%% Reject trials after visual inspection
rejtrial = [12,15,23,24,36,37,38,55,71,76,86,111,121,126,141,157,213,251]; % INPUT give vector with numbers for trials to reject;

indexes = 1:size(EEG_newchannels.data,3);
idx_keep = ismember(indexes, rejtrial); %indexes of the trials we want to reject
EEG_reject = pop_rejepoch(EEG_newchannels, idx_keep);

%% Concatenate all epochs again for further analysis
EEGout = epoch2continuous(EEG_reject);    

%% Save
EEGout.REMepochs = REM_epochs;
EEGout.NREMepochs = NREM_epochs;
EEGout.rejects = rejtrials;
EEGout.orgevents = EEG_epoched.event;
%pop_saveset(EEGout,'filename',[eegfilename,'_pre-processed.set'],'filepath',DATAOUT);

%% Create and save reference EEG dataset with all markers
badtrials = REM_epochs(rejtrial);
delmat = sort(cat(2,NREM_epochs,badtrials));

EEG_ref = EEG_filtered;
delete_epochs = [];
for i = 1:length(delmat)
     delete_epochs(i,1) = sleep_data(delmat(i)).start*512+1;
     delete_epochs(i,2) = sleep_data(delmat(i)).xEnd*512+1;
     EEG_ref.data(:,delete_epochs(i,1):delete_epochs(i,2)) = [-300];
end
% pop_eegplot(EEG_ref,1,1,1);
% pop_saveset(EEG_ref,'filename',[eegfilename,'_refEEG.set'],'filepath',DATAOUT);
%%
coi = 6; % INPUT channel of interest, Fz = 6, fpz = 2
EEG_newchannels_plusone = pop_select(EEG_ref, 'channel', coi); %using this variable to save. unfiltered, but with important epochs only

%% Create matrix with info on all blocks (not specific on REM sleep)

block_matrix = []; % matrix to put block information in
                   % column 1 = start block (latency first 101 marker)
                   % column 2 = end block (latency 104 or 105 marker)
                   % column 3 = end block-start block/512 = elapsed time in
                   % block
                   % column 4 = type of block. 000 = no stims in block
                   % column 5 = number of stimulation in block
j = 1; % variable to index row in block_matrix, changing in loop
previousstart = 0; % variable indicating if a new block has started, i.e.
                   % the first 101 event marker has been shown.
                   % 0 = no 101 marker in block yet, 1 = there has been a
                   % 101 marker in this block
for i = 1:size(EEG.event,2)
    % if a new block has started (101), skip the loop until the end of a 
    % block (104 or 105).
    if previousstart == 1 && strcmpi(EEG.event(i).type, '104') ~= 1 && strcmpi(EEG.event(i).type, '105') ~= 1
        stimcount = stimcount + 1;
        continue 
    % if the end of a block (104 or 105) is detected, note block info and 
    % reset variables
    elseif strcmpi(EEG.event(i).type, '104') == 1 || strcmpi(EEG.event(i).type, '105') == 1
        block_matrix(j,2) = EEG.event(i).latency;
        block_matrix(j,3) = (block_matrix(j,2)-block_matrix(j,1))/512;
        if strcmpi(EEG.event(i-1).type,'101')
            block_matrix(j,4) = str2num(EEG.event(i-2).type);
        else 
            block_matrix(j,4) = str2num(EEG.event(i-1).type);
        end
        if block_matrix(j,4) == 104
            block_matrix(j,4) = 000;
        end
        block_matrix(j,5) = floor(stimcount/2);
        j = j + 1;
        previousstart = 0;
        stimcount = 0;
    % if the start of a block has been detected, note the block information
    % and update variables
    elseif strcmpi(EEG.event(i).type,'101') 
        block_matrix(j,1) = EEG.event(i).latency;
        previousstart = 1;
        stimcount = 1; 
    end
end
% % REMmat = [];
% % for i = 1:length(REM_epochs)
% %      REMmat(i,1) = sleep_data(REM_epochs(i)).start*512;
% %      REMmat(i,2) = sleep_data(REM_epochs(i)).xEnd*512;
% % end
% %[a, b] = min(abs(REMmat(:,1)-block_matrix(1,1)));
% ab = [];
% for i = 1:size(block_matrix,1)
%     for j = 1:size(REMmat,1)
%         bla = find(block_matrix(i,1) > REMmat(j,1) && block_matrix(i,2) < REMmat(j,2));
%         ab = [ab bla];
%     end
% end
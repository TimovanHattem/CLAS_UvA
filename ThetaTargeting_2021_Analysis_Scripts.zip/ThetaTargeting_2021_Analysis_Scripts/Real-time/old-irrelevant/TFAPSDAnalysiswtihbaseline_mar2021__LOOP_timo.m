% ANALYSIS FOR TFA/PSD ANALYSIS THETA TARGETING
%
% Timo van Hattem & Joao Patriota
% Experiment Theta_Targeting
% Updated: 1-6-2021

%% SETTINGS

clear all
close all
clc

% Set pathS
if isempty(strfind(path, ['/home/Public/Projects/sleep-and-cognition/generic/matlab-scripts/toolboxes/eeglab_v2020', pathsep]))
    addpath('/home/Public/Projects/sleep-and-cognition/generic/matlab-scripts/toolboxes/eeglab_v2020');
end
addpath(genpath('/home/Public/Projects/sleep-and-cognition/experiments/0016.Measuring-theta-during-REM-sleep/Raw data'));
addpath('/home/Public/Projects/sleep-and-cognition/experiments/0016.Measuring-theta-during-REM-sleep/matlab-scripts/2. ZMax Analysis/Algorithm Accuracy'); % to get e.g. 'bandpass.m'
addpath(genpath('/home/Public/Projects/sleep-and-cognition/experiments/0016.Measuring-theta-during-REM-sleep/results'));
fprintf('Paths added!\n')

%% LOOP OVER ALL PARTICIPANTS
z = 1;

for i = 12
    
    % Clear workspace
    close all
    clc
    
    % Load EEG dataset in eeglab
    eeglab;
    eegfilename = ['P', num2str(i), '_epoched_testtfa_STIM.set'];
    eegpath = ['/home/Public/Projects/sleep-and-cognition/experiments/0016.Measuring-theta-during-REM-sleep/results/ThetaTargeting_2021/STA/P', num2str(i)];
    EEG_stim = pop_loadset('filename',eegfilename,'filepath',eegpath);
    eegfilename = ['P', num2str(i), '_epoched_testtfa_SHAM.set'];
    eegpath = ['/home/Public/Projects/sleep-and-cognition/experiments/0016.Measuring-theta-during-REM-sleep/results/ThetaTargeting_2021/STA/P', num2str(i)];
    EEG_sham = pop_loadset('filename',eegfilename,'filepath', eegpath);
    fprintf('EEG file loaded!\n')
    
    % Setting output file path
    pp = EEG_stim.part_num;
    if strcmpi(pp,'P66')
        pp = 'P16';
    end
    DATAOUT = ['/home/Public/Projects/sleep-and-cognition/experiments/0016.Measuring-theta-during-REM-sleep/results/ThetaTargeting_2021/STA/',pp];
    
    % Reshape data
    for j = 1:size(EEG_stim.data,3)
        data_stim(j,:) = EEG_stim.data(:,:,j);
        EEG_data_stim = double(data_stim);
        %save(['/home/Public/Projects/sleep-and-cognition/experiments/0016.Measuring-theta-during-REM-sleep/results/ThetaTargeting_2021/STA/',pp, '/', pp,'_epochs_stim_nonset.mat'], 'EEG_data_stim');
    end
    for k = 1:size(EEG_sham.data,3)
        data_sham(k,:) = EEG_sham.data(:,:,k);
        EEG_data_sham = double(data_sham);
        %save(['/home/Public/Projects/sleep-and-cognition/experiments/0016.Measuring-theta-during-REM-sleep/results/ThetaTargeting_2021/STA/',pp, '/', pp,'_epochs_sham_nonset.mat'], 'EEG_data_sham');
    end
    
    ERP_average_stim_evoked = mean(EEG_data_stim,1);
    ERP_average_sham_evoked = mean(EEG_data_sham,1);
    
    figure
    window_spectrogram = 256;
    nooverlap_spectrogram = 250;
    [s1,F1,T1,P1]=spectrogram(ERP_average_stim_evoked,window_spectrogram,nooverlap_spectrogram,1024,512); % Computes the spectrogram
    plot3([0 0],[-10 40],[0 600],'w','LineWidth',3)
    hold on
    plot3([-0.375 0.875],[3 3],[0 200],'--w','LineWidth',1)
    plot3([-0.375 0.875],[8 8],[0 200],'--w','LineWidth',1)
    hold on
    T1 = T1-0.5;
    surf(T1,F1,10*log10(abs(P1)),'EdgeColor','none');
    axis xy; axis tight; view(0,90);
    xlabel('Time', 'FontSize', 18);
    ylabel('Frequency (Hz)', 'FontSize', 18);
    title('Spectrogram Stimulation')
    colorbar
    ylim([2 30])
    caxis([-25 12])
    
    % Save figure
    figname = [DATAOUT, '/', EEG_stim.part_num, '_TFAtesttest2_STIM.jpg'];
    saveas (gcf,figname);
    close
    
    figure(2)
    [s2,F2,T2,P2]=spectrogram(ERP_average_sham_evoked,window_spectrogram,nooverlap_spectrogram,1024,512); % Computes the spectrogra
    T2 = T2-0.5;
    surf(T2,F2,10*log10(abs(P2)),'EdgeColor','none');
    hold on
    plot3([0 0],[-10 40],[0 600],'w','LineWidth',3)
    plot3([-0.375 0.875],[3 3],[0 200],'--w','LineWidth',1)
    plot3([-0.375 0.875],[8 8],[0 200],'--w','LineWidth',1)
    axis xy; axis tight; view(0,90);
    xlabel('Time', 'FontSize', 18);
    ylabel('Frequency (Hz)', 'FontSize', 18);
    title('Spectogram Sham')
    colorbar
    ylim([2 30])
    caxis([-25 12])
    
    % Save figure
    figname = [DATAOUT, '/', EEG_stim.part_num, '_TFAtesttest2_SHAM.jpg'];
    saveas (gcf,figname);
    close
    
    figure(3)
    surf(T2,F2,10*log10(abs(P1-P2)),'EdgeColor','none');
    hold on
    plot3([0 0],[-10 40],[0 600],'w','LineWidth',3)
    plot3([-0.375 0.875],[3 3],[0 200],'--w','LineWidth',1)
    plot3([-0.375 0.875],[8 8],[0 200],'--w','LineWidth',1)
    axis xy; axis tight; view(0,90);
    xlabel('Time', 'FontSize', 18);
    ylabel('Frequency (Hz)', 'FontSize', 18);
    title('Contrast (Stim-Sham)')
    colorbar
    ylim([2 30])
    caxis([-5 10])
    
    % Save figure
    figname = [DATAOUT, '/', EEG_stim.part_num, '_TFAtesttest2_CONTRAST.jpg'];
    saveas (gcf,figname);
    close
    
    % Save TFA information in struct
    TFA_info_allpp(z).Participant = pp;
    TFA_info_allpp(z).TFAStimT = T1;
    TFA_info_allpp(z).TFAStimF = F1;
    TFA_info_allpp(z).TFAStimP = P1;
    TFA_info_allpp(z).TFAShamT = T2;
    TFA_info_allpp(z).TFAShamF = F2;
    TFA_info_allpp(z).TFAShamP = P2;
    
    z = z + 1;
    
    clearvars -except z TFA_info_allpp
    
end

save(['/home/Public/Projects/sleep-and-cognition/experiments/0016.Measuring-theta-during-REM-sleep/results/ThetaTargeting_2021/STA/TOTAL AVERAGE/TFA_INFORMATION_ALLPARTICIPANTS_testtfa2.mat'], 'TFA_info_allpp');

%% TOTAL AVERAGE SPECTOGRAM
close all
load('TFA_INFORMATION_ALLPARTICIPANTS.mat')

Evoked = [33:81];
Baseline = [1:32];

for i = 1:size(TFA_info_allpp,2)
    baselinepowerstim = mean(TFA_info_allpp(i).TFAStimP(:,Baseline),2);
    TFA_info_allpp(i).TFAStimP = TFA_info_allpp(i).TFAStimP./baselinepowerstim;
    baselinepowersham = mean(TFA_info_allpp(i).TFAShamP(:,Baseline),2);
    TFA_info_allpp(i).TFAShamP = TFA_info_allpp(i).TFAShamP./baselinepowersham;
end
%%

colorax1 = [-1 5];
colorax2 = [-1.0 0.5];
for i = 1:size(TFA_info_allpp,2)
    tfamat_stim(:,:,i) = TFA_info_allpp(i).TFAStimP;
    tfamat_sham(:,:,i) = TFA_info_allpp(i).TFAShamP;
end

P1 = mean(tfamat_stim,3);
%P1 = TFA_info_allpp(3).TFAStimP;
T1 = TFA_info_allpp(1).TFAStimT;
F1 = TFA_info_allpp(1).TFAStimF;

P2 = mean(tfamat_sham,3);
%P2 = TFA_info_allpp(3).TFAShamP;
T2 = TFA_info_allpp(1).TFAStimT;
F2 = TFA_info_allpp(1).TFAStimF;

figure(1)
plot3([0 0],[-10 40],[0 600],'w','LineWidth',3)
hold on
plot3([-0.375 0.875],[3 3],[0 200],'--w','LineWidth',1)
plot3([-0.375 0.875],[8 8],[0 200],'--w','LineWidth',1)
hold on
surf(T1,F1,10*log10(abs(P1)),'EdgeColor','none');
axis xy; axis tight; view(0,90);
xlabel('Time (s)', 'FontSize', 10);
ylabel('Frequency (Hz)', 'FontSize', 10);
title('Spectrogram Stimulation')
colorbar
ylim([2 30])
caxis(colorax1)

figure(2)
surf(T2,F2,10*log10(abs(P2)),'EdgeColor','none');
hold on
plot3([0 0],[-10 40],[0 600],'w','LineWidth',3)
plot3([-0.3 0.8],[3 3],[0 200],'--w','LineWidth',1)
plot3([-0.3 0.8],[8 8],[0 200],'--w','LineWidth',1)
axis xy; axis tight; view(0,90);
xlabel('Time (s)', 'FontSize', 10);
ylabel('Frequency (Hz)', 'FontSize', 10);
title('Spectogram Sham')
colorbar
ylim([2 30])
caxis(colorax1)

figure(3)
surf(T2,F2,10*log10(abs(P1-P2)),'EdgeColor','none');
hold on
plot3([0 0],[-10 40],[0 600],'w','LineWidth',3)
plot3([-0.3 0.8],[3 3],[0 200],'--w','LineWidth',1)
plot3([-0.3 0.8],[8 8],[0 200],'--w','LineWidth',1)
axis xy; axis tight; view(0,90);
xlabel('Time (s)', 'FontSize', 10);
ylabel('Frequency (Hz)', 'FontSize', 10);
title('Contrast (Stim-Sham)')
colorbar
ylim([2 30])
caxis(colorax2)

%% PSD total

psd_stim = mean(P1(:,[33:length(T1)]),2);
psd_sham = mean(P2(:,[33:length(T1)]),2);

figure
plot(TFA_info_allpp(1).TFAStimF,10*log10(psd_stim))                % Plot for the baseline window
hold on
plot(TFA_info_allpp(1).TFAStimF,10*log10(psd_sham))% Plot for the presentation window
line([4 4], [-35 10], 'Color', 'black', 'LineStyle', '--'); %Create a tick mark at x = t1(i) with a height of 100
line([8 8], [-35 10], 'Color', 'black', 'Linestyle', '--');
xlabel('Frequency (Hz)')
ylabel('Power (a.u.)')
legend('Stimulation','Sham')
xlim([2 30])

%% Scatterplot theta increase per pp

for i = 1:size(TFA_info_allpp,2)
    theta_increase(i,1) = mean(mean(TFA_info_allpp(i).TFAStimP([9:17],[33:end]),2),1);
    theta_increase(i,2) = mean(mean(TFA_info_allpp(i).TFAShamP([9:17],[33:end]),2),1);
    theta_increase(i,3) = theta_increase(i,1)/theta_increase(i,2);
end

title('Distribution of theta increase')
scatter([1:24],theta_increase(:,3))
xlabel('Participant #')
ylabel('Ratio (theta power Stimulation/theta power Sham)')
set(gca,'XTick',[1:1:24])
set(gca,'xticklabel',({'1', '2', '3', '4', '5', '6', '7', '8', '9','10','11', '12', '13', '14', '15', '16', '17', '18', '19','20', '21', '22', '23', '24'}))
ylim([-1,60])
line([1 24], [1 1], 'color', 'red','LineStyle','--'); %Create a tick mark at x = t1(i) with a height of 100
axis square

%%
z = 1;
for i = 12:35
    pp = ['P', num2str(i)];
    load(['/home/Public/Projects/sleep-and-cognition/experiments/0016.Measuring-theta-during-REM-sleep/results/ThetaTargeting_2021/STA/',pp, '/', pp,'_epochs_stim_nonset.mat']);
    load(['/home/Public/Projects/sleep-and-cognition/experiments/0016.Measuring-theta-during-REM-sleep/results/ThetaTargeting_2021/STA/',pp, '/', pp,'_epochs_sham_nonset.mat']);
    EEG_data_stim = EEG_data_stim(:,257:768);
    EEG_data_sham = EEG_data_sham(:,257:768);
    ERP_average_stim_evoked = mean(EEG_data_stim,1);
    ERP_average_sham_evoked = mean(EEG_data_sham,1);
    
    % Pwelch for every line
    theta_range = [4 8];
    total_range = [0.3 30];
    window = 125;
    nooverlap = [];
    fftsize = 2^10;
    Fs = 512;
    
    [Pwel_stim, Fwel_stim] = pwelch(ERP_average_stim_evoked,window,nooverlap,fftsize,Fs);
    bandpower_stim = bandpower(Pwel_stim,Fwel_stim,theta_range,'psd'); %band on theta
    
    [Pwel_sham, Fwel_sham] = pwelch(ERP_average_sham_evoked,window,nooverlap,fftsize,Fs);
    bandpower_sham = bandpower(Pwel_sham,Fwel_sham,theta_range,'psd'); %band on theta
    
    ratiopower = (Pwel_stim./Pwel_sham);
    ratiobandpower = (bandpower_stim/bandpower_sham);
    
    PSD_info_allpp(z).Participant = pp;
    PSD_info_allpp(z).PowerStim = Pwel_stim;
    PSD_info_allpp(z).PowerSham = Pwel_sham;
    PSD_info_allpp(z).FwelStim = Fwel_stim;
    PSD_info_allpp(z).FwelSham = Fwel_sham;
    PSD_info_allpp(z).BandpowerStim = bandpower_stim;
    PSD_info_allpp(z).BandpowerSham = bandpower_sham;
    PSD_info_allpp(z).PowerRatio = ratiopower;
    PSD_info_allpp(z).BandpowerRatio = ratiobandpower;
    
    z = z + 1;
end

%%

for i = 1:size(PSD_info_allpp,2)
    psdmat_stim(:,i) = PSD_info_allpp(i).PowerStim;
    psdmat_sham(:,i) = PSD_info_allpp(i).PowerSham;
    psdmat_ratio(:,i) = PSD_info_allpp(i).PowerRatio;
end
meanpower_stim = mean(psdmat_stim, 2);
meanpower_sham = mean(psdmat_sham,2);
meanpower_ratio = mean(psdmat_ratio,2);

% Plot Power spectrum
figure(1)
subplot 121
plot(PSD_info_allpp(1).FwelStim,10*log10(meanpower_stim))                % Plot for the baseline window
hold on
plot(PSD_info_allpp(1).FwelSham,10*log10(meanpower_sham))            % Plot for the presentation window
line([theta_range(1) theta_range(1)], [-40 20], 'color', 'red'); %Create a tick mark at x = t1(i) with a height of 100
line([theta_range(2) theta_range(2)], [-40 20], 'color', 'red'); %Create a tick mark at x = t1(i) with a height of 100
legend('stim','no stim')
xlim([2 30])
axis square

subplot 122
plot(PSD_info_allpp(1).FwelStim,meanpower_ratio)
line([1 40], [1 1], 'color', 'red','LineStyle','--'); %Create a tick mark at x = t1(i) with a height of 100
xlim([2 30])
axis square

figure(2)
meanbandstim = mean([PSD_info_allpp.BandpowerStim],2);
stdbandstim = std([PSD_info_allpp.BandpowerStim]);
meanbandsham = mean([PSD_info_allpp.BandpowerSham],2);
stdbandsham = std([PSD_info_allpp.BandpowerSham]);
bar([meanbandstim, meanbandsham])
hold on
errorbar([1:2],[meanbandstim, meanbandsham], [stdbandstim, stdbandsham],[stdbandstim, stdbandsham], 'LineStyle', 'none', 'Color', 'black');
set(gca,'XTick',[1,2])
set(gca,'xticklabel',({'Stimulation', 'Sham'}))
ylim([0,12])
title('Bandpower comparison')
xlabel('Condition', 'FontSize', 12)
ylabel('Theta bandpower post-stimulus (dB)', 'FontSize', 12)

figure(3)
title('Distribution participants post-stimulus')
scatter([1:24],[PSD_info_allpp.BandpowerRatio])
xlabel('Participant #')
ylabel('Ratio (theta power Stimulation/theta power Sham)')
set(gca,'XTick',[1:24])
set(gca,'xticklabel',({'1', '2', '3', '4', '5', '6', '7', '8', '9','10','11', '12', '13', '14', '15', '16', '17', '18', '19','20', '21', '22', '23', '24'}))
ylim([-1,40])
line([1 24], [1 1], 'color', 'red','LineStyle','--'); %Create a tick mark at x = t1(i) with a height of 100
axis square
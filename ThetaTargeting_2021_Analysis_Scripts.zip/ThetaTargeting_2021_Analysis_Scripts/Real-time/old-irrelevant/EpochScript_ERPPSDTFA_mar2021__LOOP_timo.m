% ANALYSIS FOR ERP/TFA/PSD ANALYSIS THETA TARGETING
%
% Timo van Hattem & Joao Patriota
% Experiment Theta_Targeting
% Updated: 1-6-2021

%% SETTINGS

clear all
close all
clc

% Set pathS
if isempty(strfind(path, ['/home/Public/Projects/sleep-and-cognition/generic/matlab-scripts/toolboxes/eeglab_v2020', pathsep]))
    addpath('/home/Public/Projects/sleep-and-cognition/generic/matlab-scripts/toolboxes/eeglab_v2020');
end
addpath(genpath('/home/Public/Projects/sleep-and-cognition/experiments/0016.Measuring-theta-during-REM-sleep/Raw data'));
addpath('/home/Public/Projects/sleep-and-cognition/experiments/0016.Measuring-theta-during-REM-sleep/matlab-scripts/2. ZMax Analysis/Algorithm Accuracy'); % to get e.g. 'bandpass.m'
addpath(genpath('/home/Public/Projects/sleep-and-cognition/experiments/0016.Measuring-theta-during-REM-sleep/results'));
fprintf('Paths added!\n')

%% LOOP OVER ALL PARTICIPANTS
z = 1;

for i = 12:35

    % Clear workspace
    close all
    clc

    % Load EEG dataset in eeglab
    eeglab;
    eegfilename = ['P', num2str(i), '_epoched_clean_STIM.set'];
    eegpath = ['/home/Public/Projects/sleep-and-cognition/experiments/0016.Measuring-theta-during-REM-sleep/results/ThetaTargeting_2021/STA/P', num2str(i)];
    EEG_stim = pop_loadset('filename',eegfilename,'filepath',eegpath);
    eegfilename = ['P', num2str(i), '_epoched_clean_SHAM.set'];
    eegpath = ['/home/Public/Projects/sleep-and-cognition/experiments/0016.Measuring-theta-during-REM-sleep/results/ThetaTargeting_2021/STA/P', num2str(i)];
    EEG_sham = pop_loadset('filename',eegfilename,'filepath', eegpath);
    fprintf('EEG file loaded!\n')

    % Setting output file path
    pp = EEG_stim.part_num;
    if strcmpi(pp,'P66')
        pp = 'P16';
    end 
    DATAOUT = ['/home/Public/Projects/sleep-and-cognition/experiments/0016.Measuring-theta-during-REM-sleep/results/ThetaTargeting_2021/STA/',pp];

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%ERP%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Averaging trials
    average_erp_stim = mean(EEG_stim.data,3);
    average_erp_sham = mean(EEG_sham.data,3);

    % Plot ERP image
    figure;
    x = [-256:1:511];
    plot(x,average_erp_stim, 'b')
    hold on
    plot(x,average_erp_sham, 'r')
    xlim([-256 511])
    xlabel('Time (ms)')
    ylabel(['Amplitude (', char(181),'V)'])
    line([0 0], [-30 30], 'color', 'black')
    legend('Stimulation', 'Sham')

    % Save figure
    figname = [DATAOUT, '/', EEG_stim.part_num, '_ERPs.jpg'];
    saveas (gcf,figname);
    close

    % Save ERP information in struct
    ERP_info_allpp(z).Participant = pp;
    ERP_info_allpp(z).AverageERPStim = average_erp_stim;
    ERP_info_allpp(z).AverageERPSham = average_erp_sham;

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%PSD%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Reshape data
    for j = 1:size(EEG_stim.data,3)
        datavecstim = EEG_stim.data(:,:,j);
        data_stim(j,:) = datavecstim;
        EEG_data_stim = double(data_stim);
        save(['/home/Public/Projects/sleep-and-cognition/experiments/0016.Measuring-theta-during-REM-sleep/results/ThetaTargeting_2021/STA/',pp, '/', pp,'_epochs_stim_nonset.mat'], 'EEG_data_stim');
    end
    for k = 1:size(EEG_sham.data,3)
        datavecsham = EEG_sham.data(:,:,k);
        data_sham(k,:) = datavecsham;
        EEG_data_sham = double(data_sham);
        save(['/home/Public/Projects/sleep-and-cognition/experiments/0016.Measuring-theta-during-REM-sleep/results/ThetaTargeting_2021/STA/',pp, '/', pp,'_epochs_sham_nonset.mat'], 'EEG_data_sham');
    end
    
    % Pwelch for every line
    theta_range = [4 8];
    total_range = [0.3 30];
    window = 125;
    nooverlap = [];
    fftsize = 2^10;
    Fs = 512;
    
    Pwel_stim = [];
    bandpower_stim = [];
    for l = 1:size(EEG_data_stim,1)
        [Pwel_stim(l,:), Fwel_stim] = pwelch(EEG_data_stim(l,:),window,nooverlap,fftsize,Fs);
        bandpower_stim(l,:) = bandpower(Pwel_stim(l,:),Fwel_stim,theta_range,'psd'); %band on theta
    end
    
    Pwel_sham = [];
    bandpower_sham = [];
    for m = 1:size(EEG_data_sham,1)
        [Pwel_sham(m,:), Fwel_sham] = pwelch(EEG_data_sham(m,:),window,nooverlap,fftsize,Fs);
        bandpower_sham(m,:) = bandpower(Pwel_sham(m,:),Fwel_sham,theta_range,'psd'); %band on theta
    end
    
    meanpower_stim = mean(Pwel_stim,1); %average power of power per
    meanbandpower_stim = mean(bandpower_stim,1); %band on theta
    
    meanpower_sham = mean(Pwel_sham,1); %average power of power per
    meanbandpower_sham = mean(bandpower_sham,1); %band on theta
    
    meanpower_stim_norm = meanpower_stim./max(meanpower_stim); %normalizing meanpower
    bandpower_stim_norm = bandpower(meanpower_stim_norm,Fwel_stim,theta_range,'psd'); %normalized band on theta
    
    meanpower_sham_norm = meanpower_sham./max(meanpower_sham); %normalizing
    bandpower_sham_norm = bandpower(meanpower_sham_norm,Fwel_sham,theta_range,'psd'); %bandpower on normalized
    
    meanpower_ratio = (meanpower_stim./meanpower_sham);
    meanpower_ratio_norm = (meanpower_stim_norm./meanpower_sham_norm);
    
    % Plot Power spectrum
    figure
    subplot 131
    plot(Fwel_stim,10*log10(meanpower_stim))                % Plot for the baseline window
    hold on
    plot(Fwel_sham,10*log10(meanpower_sham))            % Plot for the presentation window
    line([theta_range(1) theta_range(1)], [0 20], 'color', 'red'); %Create a tick mark at x = t1(i) with a height of 100
    line([theta_range(2) theta_range(2)], [0 20], 'color', 'red'); %Create a tick mark at x = t1(i) with a height of 100
    legend('stim','no stim')
    xlim([2 30])
    axis square
    subplot 132
    plot(Fwel_stim,meanpower_ratio)
    line([1 40], [1 1], 'color', 'red','LineStyle','--'); %Create a tick mark at x = t1(i) with a height of 100
    xlim([2 40])
    axis square
    subplot 133
    bandpower_comb = [meanbandpower_stim, meanbandpower_sham];
    bar(bandpower_comb)
    axis square
    
    % Save figure
    figname = [DATAOUT, '/', EEG_stim.part_num, '_PSDs.jpg'];
    saveas (gcf,figname);
    close
    
    % Save PSD information in struct
    PSD_info_allpp(z).Participant = pp;
    PSD_info_allpp(z).MeanPowerStim = meanpower_stim;
    PSD_info_allpp(z).MeanPowerSham = meanpower_sham;
    PSD_info_allpp(z).MeanBandpowerStim = meanbandpower_stim;
    PSD_info_allpp(z).MeanBandpowerSham = meanbandpower_sham;
    PSD_info_allpp(z).MeanPowerRatio = meanpower_ratio;
    PSD_info_allpp(z).MeanPowerStimNorm = meanpower_stim_norm;
    PSD_info_allpp(z).MeanPowerShamNorm = meanpower_sham_norm;
    PSD_info_allpp(z).MeanBandpowerStimNorm = bandpower_stim_norm;
    PSD_info_allpp(z).MeanBandpowerShamNorm = bandpower_sham_norm;
    PSD_info_allpp(z).MeanPowerRatioNorm = meanpower_ratio_norm;
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%TFA%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    STA_average_stim_evoked = mean(EEG_data_stim,1);
    STA_average_sham_evoked = mean(EEG_data_sham,1);
    
    figure
    window_spectrogram = 128;
    nooverlap_spectrogram = 120;
    [s1,F1,T1,P1]=spectrogram(STA_average_stim_evoked,window_spectrogram,nooverlap_spectrogram,1024,512); % Computes the spectrogram
    plot3([0 0],[-10 40],[0 600],'w','LineWidth',3)
    hold on
    plot3([-0.3 0.8],[3 3],[0 200],'--w','LineWidth',1)
    plot3([-0.3 0.8],[8 8],[0 200],'--w','LineWidth',1)
    hold on
    T1 = T1-0.5;
    surf(T1,F1,10*log10(abs(P1)),'EdgeColor','none');
    axis xy; axis tight; view(0,90);
    xlabel('Time', 'FontSize', 18);
    ylabel('Frequency (Hz)', 'FontSize', 18);
    title('Spectrogram Stimulation')
    colorbar
    ylim([2 30])
    caxis([-25 12])
    
    % Save figure
    figname = [DATAOUT, '/', EEG_stim.part_num, '_TFA_STIM.jpg'];
    saveas (gcf,figname);
    close
    
    figure
    [s2,F2,T2,P2]=spectrogram(STA_average_sham_evoked,window_spectrogram,nooverlap_spectrogram,1024,512); % Computes the spectrogra
    T2 = T2-0.5;
    surf(T2,F2,10*log10(abs(P2)),'EdgeColor','none');
    hold on
    plot3([0 0],[-10 40],[0 600],'w','LineWidth',3)
    plot3([-0.3 0.8],[3 3],[0 200],'--w','LineWidth',1)
    plot3([-0.3 0.8],[8 8],[0 200],'--w','LineWidth',1)
    axis xy; axis tight; view(0,90);
    xlabel('Time', 'FontSize', 18);
    ylabel('Frequency (Hz)', 'FontSize', 18);
    title('Spectogram Sham')
    colorbar
    ylim([2 30])
    caxis([-25 12])
    
    % Save figure
    figname = [DATAOUT, '/', EEG_stim.part_num, '_TFA_SHAM.jpg'];
    saveas (gcf,figname);
    close
    
    figure
    surf(T2,F2,10*log10(abs(P1-P2)),'EdgeColor','none');
    hold on
    plot3([0 0],[-10 40],[0 600],'w','LineWidth',3)
    plot3([-0.3 0.8],[3 3],[0 200],'--w','LineWidth',1)
    plot3([-0.3 0.8],[8 8],[0 200],'--w','LineWidth',1)
    axis xy; axis tight; view(0,90);
    xlabel('Time', 'FontSize', 18);
    ylabel('Frequency (Hz)', 'FontSize', 18);
    title('Contrast (Stim-Sham)')
    colorbar
    ylim([2 30])
    caxis([-5 10])
    
    % Save figure
    figname = [DATAOUT, '/', EEG_stim.part_num, '_TFA_CONTRAST.jpg'];
    saveas (gcf,figname);
    close 
    
    % Save TFA information in struct
    TFA_info_allpp(z).Participant = pp;
    TFA_info_allpp(z).TFAStimT = T1;
    TFA_info_allpp(z).TFAStimF = F1;
    TFA_info_allpp(z).TFAStimP = P1;
    TFA_info_allpp(z).TFAShamT = T2;
    TFA_info_allpp(z).TFAShamF = F2;
    TFA_info_allpp(z).TFAShamP = P2;
    
    z = z + 1;
    
    clearvars -except z ERP_info_allpp PSD_info_allpp TFA_info_allpp
end

save(['/home/Public/Projects/sleep-and-cognition/experiments/0016.Measuring-theta-during-REM-sleep/results/ThetaTargeting_2021/STA/TOTAL AVERAGE/ERP_INFORMATION_ALLPARTICIPANTS.mat'], 'ERP_info_allpp');
save(['/home/Public/Projects/sleep-and-cognition/experiments/0016.Measuring-theta-during-REM-sleep/results/ThetaTargeting_2021/STA/TOTAL AVERAGE/PSD_INFORMATION_ALLPARTICIPANTS.mat'], 'PSD_info_allpp');
save(['/home/Public/Projects/sleep-and-cognition/experiments/0016.Measuring-theta-during-REM-sleep/results/ThetaTargeting_2021/STA/TOTAL AVERAGE/TFA_INFORMATION_ALLPARTICIPANTS.mat'], 'TFA_info_allpp');


